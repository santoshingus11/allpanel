<!DOCTYPE html>
<!-- saved from url=(0032){{asset('/login')}}/login -->
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="origin-trial" content="Az520Inasey3TAyqLyojQa8MnmCALSEU29yQFW8dePZ7xQTvSt73pHazLFTK5f7SyLUJSo2uKLesEtEa9aUYcgMAAACPeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZyIsImV4cGlyeSI6MTcyNTQwNzk5OSwiaXNTdWJkb21haW4iOnRydWUsImlzVGhpcmRQYXJ0eSI6dHJ1ZX0=">

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>ALLPANEL</title>
    <!--<base href="/">-->
    <base href=".">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
    <meta content="" name="description">
    <meta content="" name="keywords">
    <link rel="icon" type="image/x-icon" href="{{asset('/login')}}/favicon.ico">
    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->

    <!-- Google Fonts -->
    <style type="text/css">
        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYNNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoadNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYdNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoY9NZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobdNZUSdy4Q.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAgM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLCwM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAwM9QPFUex17.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDAM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAAM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAQM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDwM9QPFUew.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYNNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoadNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYdNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoY9NZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobdNZUSdy4Q.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCkYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCAYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCgYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCcYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCsYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCoYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCQYb9lecyU.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19-7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19a7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1967DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19G7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1927DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19y7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19K7DQk6YvM.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCkYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCAYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCgYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCcYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCsYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCoYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCQYb9lecyU.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
    </style>

    <!-- assets CSS Files -->
    <style>
        :root {
            --blue: #007bff;
            --indigo: #6610f2;
            --purple: #6f42c1;
            --pink: #e83e8c;
            --red: #dc3545;
            --orange: #fd7e14;
            --yellow: #ffc107;
            --green: #28a745;
            --teal: #20c997;
            --cyan: #17a2b8;
            --white: #fff;
            --gray: #6c757d;
            --gray-dark: #343a40;
            --primary: #007bff;
            --secondary: #6c757d;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --breakpoint-xs: 0;
            --breakpoint-sm: 576px;
            --breakpoint-md: 768px;
            --breakpoint-lg: 992px;
            --breakpoint-xl: 1200px;
            --font-family-sans-serif: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            --font-family-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        }

        *,
        ::after,
        ::before {
            box-sizing: border-box;
        }

        html {
            font-family: sans-serif;
            line-height: 1.15;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            margin: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            text-align: left;
            background-color: #fff;
        }

        @media print {

            *,
            ::after,
            ::before {
                text-shadow: none !important;
                box-shadow: none !important;
            }

            @page {
                size: a3;
            }

            body {
                min-width: 992px !important;
            }
        }
    </style>
    <link href="{{asset('/login')}}/bootstrap.min.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    </noscript>
    <link rel="stylesheet" href="{{asset('/login')}}/bs-datepicker.css">
    <link href="{{asset('/login')}}/card-characters" rel="stylesheet">

    <style>
        @import url('https://fonts.cdnfonts.com/css/card-characters');

        .card-icon {
            font-family: Card Characters;
            width: 24px;
            text-align: right;
            display: inline-block;
        }

        .card-red {
            color: #ff0000;
        }

        .card-black {
            color: #000000;
        }
    </style>



    <!-- Template Main CSS File -->
    <link rel="stylesheet" href="{{asset('/login')}}/theme.css" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/theme.css">
    </noscript>
    <style>
        @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css");

        body {
            font-family: "Roboto Condensed", sans-serif !important;
            color: #272829;
        }

        @media (max-width: 767px) {}
    </style>
    <link href="{{asset('/login')}}/style.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/style.css">
    </noscript>
    <link href="{{asset('/login')}}/casinos.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/casinos.css">
    </noscript>
    <style>
        @import url("https://use.fontawesome.com/releases/v5.0.10/css/all.css");

        body {
            font-family: 'Roboto Condensed', sans-serif !important;
            color: #272829;
        }
    </style>
    <link href="{{asset('/login')}}/login.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/login.css">
    </noscript>
    <script type="text/javascript" async="" src="{{asset('/login')}}/recaptcha__en.js.download" crossorigin="anonymous" integrity="sha384-jqt/W+w17r4O2YInpGAzsGqUkWuFwLH1iwGKOM8Z//8l09d6UkRjn4GYUmr6Agro"></script>
    <script>
        const hosts = [{
                domain: "localhost",
                description: "Bet with the most trusted online betting exchange in India. Get the best odds, instant withdrawals & deposits, 24/7 customer service and refer bonus. Sign up now!",
            },
            {
                domain: "funexch.net",
                description: "Register Now On India's 1st Licensed Online Casino And Sportsbook. Experience 24/7 Customer Service, Auto Deposit/withdrawal, And 1000+ Live Casino Games & Sports Betting Games. Enjoy 6% Bonus On Every Deposit!"
            }

        ];
        const host = hosts?.find((host) => host?.domain === window.location.hostname);
        if (host) {
            const newMetaTag = document.createElement("meta");
            newMetaTag.name = "description";
            newMetaTag.content = host?.description;
            if (document.querySelector("meta[name='description']")) {
                document.querySelector("meta[name='description']").replaceWith(newMetaTag);
            } else {
                document.head.appendChild(newMetaTag);
            }
        }
    </script>

    <script src="{{asset('/login')}}/jquery-3.5.1.min.js.download"></script>

    <script src="{{asset('/login')}}/jquery.min.js.download"></script>
    <script src="{{asset('/login')}}/bootstrap.bundle.min.js.download"></script>
    <script type="text/javascript" src="{{asset('/login')}}/jquery.dataTables.min.js.download"></script>
    <script type="text/javascript" src="{{asset('/login')}}/dataTables.bootstrap4.min.js.download"></script>
    <style>
        @charset "UTF-8";

        :root {
            --bs-blue: #0d6efd;
            --bs-indigo: #6610f2;
            --bs-purple: #6f42c1;
            --bs-pink: #d63384;
            --bs-red: #dc3545;
            --bs-orange: #fd7e14;
            --bs-yellow: #ffc107;
            --bs-green: #198754;
            --bs-teal: #20c997;
            --bs-cyan: #0dcaf0;
            --bs-black: #000;
            --bs-white: #fff;
            --bs-gray: #6c757d;
            --bs-gray-dark: #343a40;
            --bs-gray-100: #f8f9fa;
            --bs-gray-200: #e9ecef;
            --bs-gray-300: #dee2e6;
            --bs-gray-400: #ced4da;
            --bs-gray-500: #adb5bd;
            --bs-gray-600: #6c757d;
            --bs-gray-700: #495057;
            --bs-gray-800: #343a40;
            --bs-gray-900: #212529;
            --bs-primary: #0d6efd;
            --bs-secondary: #6c757d;
            --bs-success: #198754;
            --bs-info: #0dcaf0;
            --bs-warning: #ffc107;
            --bs-danger: #dc3545;
            --bs-light: #f8f9fa;
            --bs-dark: #212529;
            --bs-primary-rgb: 13, 110, 253;
            --bs-secondary-rgb: 108, 117, 125;
            --bs-success-rgb: 25, 135, 84;
            --bs-info-rgb: 13, 202, 240;
            --bs-warning-rgb: 255, 193, 7;
            --bs-danger-rgb: 220, 53, 69;
            --bs-light-rgb: 248, 249, 250;
            --bs-dark-rgb: 33, 37, 41;
            --bs-white-rgb: 255, 255, 255;
            --bs-black-rgb: 0, 0, 0;
            --bs-body-color-rgb: 33, 37, 41;
            --bs-body-bg-rgb: 255, 255, 255;
            --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            --bs-gradient: linear-gradient(180deg, #ffffff26, #fff0);
            --bs-body-font-family: var(--bs-font-sans-serif);
            --bs-body-font-size: 1rem;
            --bs-body-font-weight: 400;
            --bs-body-line-height: 1.5;
            --bs-body-color: #212529;
            --bs-body-bg: #fff;
            --bs-border-width: 1px;
            --bs-border-style: solid;
            --bs-border-color: #dee2e6;
            --bs-border-color-translucent: rgba(0, 0, 0, .175);
            --bs-border-radius: 0.375rem;
            --bs-border-radius-sm: 0.25rem;
            --bs-border-radius-lg: 0.5rem;
            --bs-border-radius-xl: 1rem;
            --bs-border-radius-2xl: 2rem;
            --bs-border-radius-pill: 50rem;
            --bs-link-color: #0d6efd;
            --bs-link-hover-color: #0a58ca;
            --bs-code-color: #d63384;
            --bs-highlight-bg: #fff3cd;
        }

        *,
        :after,
        :before {
            box-sizing: border-box;
        }

        @media (prefers-reduced-motion:no-preference) {
            :root {
                scroll-behavior: smooth;
            }
        }

        body {
            margin: 0;
            font-family: var(--bs-body-font-family);
            font-size: var(--bs-body-font-size);
            font-weight: var(--bs-body-font-weight);
            line-height: var(--bs-body-line-height);
            color: var(--bs-body-color);
            text-align: var(--bs-body-text-align);
            background-color: var(--bs-body-bg);
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }
    </style>
    <link rel="stylesheet" href="{{asset('/login')}}/styles.1f3b1d3fc8356a080acf.css" media="all" onload="this.media=&#39;all&#39;"><noscript>
        <link rel="stylesheet" href="styles.1f3b1d3fc8356a080acf.css">
    </noscript>
    <style></style>
    <style>
        :root {
            --primary: #08c;
            --secondary: #092844;
            --third: #2b329bE6;
            --forth: #092844D9;
            --fifth: #fff;
            --heading-text-color: #fff;
            --active-heading-text-color: #fff;
            --bet-btn: #28a745;
            --stake-btn: #092844;
            --login1: #08c;
            --login2: #092844
        }
    </style>
    <script src="{{asset('/login')}}/api.js.download" async="" defer=""></script>
    <style>
        .text-custom[_ngcontent-nyb-c72] {
            color: #fff
        }

        .loader[_ngcontent-nyb-c72] {
            min-height: 100px;
            position: relative
        }

        #overlay[_ngcontent-nyb-c72] {
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10;
            background-color: #000000e6
        }

        .dots-circle-spinner[_ngcontent-nyb-c72] {
            display: inline-block;
            height: 1em;
            width: 1em;
            line-height: 1;
            vertical-align: middle;
            border-radius: 1em;
            transition: all .15s linear 0s;
            transform: scale(0);
            opacity: 0;
            box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
        }

        .dots-circle-spinner.loading[_ngcontent-nyb-c72] {
            transform: scale(.5);
            opacity: 1;
            animation: dots-circle-rotation 1.5s linear .15s infinite normal forwards running
        }

        @keyframes dots-circle-rotation {
            to {
                box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
            }

            87.5% {
                box-shadow: 2em 0 0 -.4375em, 1.41421356em 1.41421356em 0 -.375em, 0 2em 0 -.3125em, -1.41421356em 1.41421356em 0 -.25em, -2em 0 0 -.1875em, -1.41421356em -1.41421356em 0 -.125em, 0 -2em 0 -.0625em, 1.41421356em -1.41421356em 0 0
            }

            75% {
                box-shadow: 2em 0 0 -.375em, 1.41421356em 1.41421356em 0 -.3125em, 0 2em 0 -.25em, -1.41421356em 1.41421356em 0 -.1875em, -2em 0 0 -.125em, -1.41421356em -1.41421356em 0 -.0625em, 0 -2em 0 0, 1.41421356em -1.41421356em 0 -.4375em
            }

            62.5% {
                box-shadow: 2em 0 0 -.3125em, 1.41421356em 1.41421356em 0 -.25em, 0 2em 0 -.1875em, -1.41421356em 1.41421356em 0 -.125em, -2em 0 0 -.0625em, -1.41421356em -1.41421356em 0 0, 0 -2em 0 -.4375em, 1.41421356em -1.41421356em 0 -.375em
            }

            50% {
                box-shadow: 2em 0 0 -.25em, 1.41421356em 1.41421356em 0 -.1875em, 0 2em 0 -.125em, -1.41421356em 1.41421356em 0 -.0625em, -2em 0 0 0, -1.41421356em -1.41421356em 0 -.4375em, 0 -2em 0 -.375em, 1.41421356em -1.41421356em 0 -.3125em
            }

            37.5% {
                box-shadow: 2em 0 0 -.1875em, 1.41421356em 1.41421356em 0 -.125em, 0 2em 0 -.0625em, -1.41421356em 1.41421356em 0 0, -2em 0 0 -.4375em, -1.41421356em -1.41421356em 0 -.375em, 0 -2em 0 -.3125em, 1.41421356em -1.41421356em 0 -.25em
            }

            25% {
                box-shadow: 2em 0 0 -.125em, 1.41421356em 1.41421356em 0 -.0625em, 0 2em 0 0, -1.41421356em 1.41421356em 0 -.4375em, -2em 0 0 -.375em, -1.41421356em -1.41421356em 0 -.3125em, 0 -2em 0 -.25em, 1.41421356em -1.41421356em 0 -.1875em
            }

            12.5% {
                box-shadow: 2em 0 0 -.0625em, 1.41421356em 1.41421356em 0 0, 0 2em 0 -.4375em, -1.41421356em 1.41421356em 0 -.375em, -2em 0 0 -.3125em, -1.41421356em -1.41421356em 0 -.25em, 0 -2em 0 -.1875em, 1.41421356em -1.41421356em 0 -.125em
            }

            0% {
                box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
            }
        }
    </style>
    <style>
        .flex-grid[_ngcontent-nyb-c77] {
            display: flex;
            text-align: center;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 18px;
            color: #fff;
            padding: 0;
            width: 100%;
            margin: 0
        }

        .flex-child[_ngcontent-nyb-c77] {
            width: 50%;
            text-align: center;
            background-color: #bb1919
        }

        .flex-child[_ngcontent-nyb-c77]:nth-child(2) {
            background-color: #8a1538
        }

        .flex-child__content[_ngcontent-nyb-c77] {
            display: inline-block;
            background-color: initial;
            width: 100%;
            text-align: center
        }

        .top-nav-event[_ngcontent-nyb-c77] {
            background: #1a5684 !important;
            scrollbar-width: 0 !important
        }

        .top-nav-event[_ngcontent-nyb-c77]::webkit-scrollbar {
            width: 0 !important;
            background: #0000 !important;
            display: none !important
        }

        .bg-color[_ngcontent-nyb-c77] {
            background: #101450 !important
        }
    </style>
    <style>
        b[_ngcontent-nyb-c74] {
            font-weight: 400 !important
        }

        .searchAnchor[_ngcontent-nyb-c74] {
            color: #000 !important
        }

        .searchAnchor[_ngcontent-nyb-c74]:hover {
            color: #fff !important
        }

        .game-date[_ngcontent-nyb-c74],
        .search-game-name[_ngcontent-nyb-c74] {
            float: left;
            width: 50%
        }

        .game-teams[_ngcontent-nyb-c74] {
            width: 100%;
            float: left
        }

        .searchM[_ngcontent-nyb-c74] .search[_ngcontent-nyb-c74] {
            position: absolute;
            margin: auto;
            top: 0;
            right: 0;
            bottom: 0;
            left: 8px;
            width: 30px;
            height: 30px;
            background: #fff;
            border-radius: 50%;
            transition: all 1s;
            z-index: 4;
            text-align: center;
            line-height: 30px
        }

        .searchM[_ngcontent-nyb-c74] .search[_ngcontent-nyb-c74]:hover {
            cursor: pointer
        }

        .searchM[_ngcontent-nyb-c74] input[_ngcontent-nyb-c74] {
            position: absolute;
            margin: auto;
            text-align: left;
            top: 0;
            right: 0;
            bottom: 0;
            left: 8px;
            width: auto;
            height: 30px;
            outline: none;
            border: none;
            background: #fff;
            color: #000;
            border-radius: 30px;
            transition: all 1s;
            opacity: 0;
            z-index: 5;
            font-weight: bolder
        }

        .searchM[_ngcontent-nyb-c74] input[_ngcontent-nyb-c74]:hover {
            cursor: pointer
        }

        .searchM[_ngcontent-nyb-c74] input[_ngcontent-nyb-c74]:focus {
            width: 200px;
            opacity: 1;
            cursor: text
        }

        .searchM[_ngcontent-nyb-c74] input[_ngcontent-nyb-c74]:focus~.search[_ngcontent-nyb-c74] {
            right: -360px;
            background: #fff;
            z-index: 6
        }

        .searchM[_ngcontent-nyb-c74] input[_ngcontent-nyb-c74]:focus~.search[_ngcontent-nyb-c74]:before {
            top: 0;
            left: 0;
            width: 25px
        }

        .searchM[_ngcontent-nyb-c74] input[_ngcontent-nyb-c74]:focus~.search[_ngcontent-nyb-c74]:after {
            top: 0;
            left: 0;
            width: 25px;
            height: 2px;
            border: none;
            background: #fff;
            border-radius: 0;
            transform: rotate(-45deg)
        }

        .searchM[_ngcontent-nyb-c74] input[_ngcontent-nyb-c74]::placeholder {
            color: #000;
            opacity: .5;
            font-weight: bolder
        }
    </style>
    <style>
        .collapse[_ngcontent-nyb-c75] {
            cursor: pointer
        }
    </style>
    <style>
        b[_ngcontent-nyb-c80] {
            font-weight: 400 !important
        }

        .dash_casino[_ngcontent-nyb-c80] h2[_ngcontent-nyb-c80] {
            display: block;
            padding-left: 10px;
            text-align: left
        }

        .listing_screen[_ngcontent-nyb-c80] h2[_ngcontent-nyb-c80] {
            background: #0000
        }

        .live-casino-block[_ngcontent-nyb-c80] {
            margin-right: 0;
            width: 100%;
            height: 106px
        }

        .live-casino-img[_ngcontent-nyb-c80] {
            width: 100% !important;
            height: 100px
        }

        .live-casino-title[_ngcontent-nyb-c80] {
            font-size: 9px !important;
            border-radius: 0
        }

        .coupon-card[_ngcontent-nyb-c80] {
            margin-bottom: 16px;
            border-radius: 0 0 2px 2px
        }

        .table-bordered[_ngcontent-nyb-c80] {
            border: 1px solid #dee2e6
        }

        .coupon-table[_ngcontent-nyb-c80] {
            margin-bottom: 0
        }

        .text-dark[_ngcontent-nyb-c80] {
            color: #343a40 !important
        }

        .coupon-table[_ngcontent-nyb-c80] tr[_ngcontent-nyb-c80] td[_ngcontent-nyb-c80]:first-child {
            padding-left: 15px;
            vertical-align: middle;
            padding-right: 15px
        }

        .coupon-table[_ngcontent-nyb-c80] tr[_ngcontent-nyb-c80] td[_ngcontent-nyb-c80] {
            padding: 0;
            vertical-align: middle;
            font-size: 14px;
            word-wrap: break-word
        }

        .horse-time-detail[_ngcontent-nyb-c80] {
            display: flex;
            flex-wrap: wrap;
            padding: 5px 5px 0
        }

        .horse-time-detail[_ngcontent-nyb-c80] a[_ngcontent-nyb-c80] {
            display: flex
        }

        .horse-time-detail[_ngcontent-nyb-c80] span[_ngcontent-nyb-c80] {
            font-size: 12px;
            background: #092844;
            color: #fff;
            padding: 5px 10px;
            border-radius: 4px;
            margin-right: 5px;
            margin-bottom: 5px;
            cursor: pointer;
            position: relative;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            -ms-border-radius: 4px;
            -o-border-radius: 4px
        }

        .horse-time-detail[_ngcontent-nyb-c80] span.active[_ngcontent-nyb-c80] {
            position: relative
        }

        .horse-time-detail[_ngcontent-nyb-c80] span.active[_ngcontent-nyb-c80]:before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            border-right: 10px solid #0000;
            border-top: 10px solid green
        }

        .bet-table.horse-table[_ngcontent-nyb-c80] .row[_ngcontent-nyb-c80] {
            border: 1px solid #ddd
        }

        .bet-table.horse-table[_ngcontent-nyb-c80] .row[_ngcontent-nyb-c80] .col-12[_ngcontent-nyb-c80] {
            border-left: 1px solid #ddd
        }

        .casinoicons[_ngcontent-nyb-c80] {
            margin-right: 0;
            margin-bottom: 16px;
            box-shadow: none
        }

        .grid-container[_ngcontent-nyb-c80] {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
            grid-gap: 6px;
            gap: 6px;
            padding: 0 10px
        }

        .img-fluid[_ngcontent-nyb-c80] {
            border-radius: 4px 4px 0 0
        }

        .game-img[_ngcontent-nyb-c80] {
            width: 100%;
            height: 150px
        }

        .games-name[_ngcontent-nyb-c80] {
            background: #1a5684;
            width: 33.33%;
            padding: 6px;
            color: #fff;
            font-size: 12px;
            text-align: center
        }

        .cursor[_ngcontent-nyb-c80] {
            cursor: pointer
        }

        @media (max-width: 767px) {
            .grid-container[_ngcontent-nyb-c80] {
                grid-template-columns: repeat(auto-fill, minmax(84px, 1fr))
            }

            .bet-table.horse-table[_ngcontent-nyb-c80] .row[_ngcontent-nyb-c80] .col-12[_ngcontent-nyb-c80] {
                border-left: none
            }

            .game-img[_ngcontent-nyb-c80] {
                height: 100px
            }

            .horse-time-detail[_ngcontent-nyb-c80] span[_ngcontent-nyb-c80] {
                background: #092844;
                color: #fff;
                padding: 4px 6px
            }

            .horse-time-detail[_ngcontent-nyb-c80] {
                padding: 0
            }
        }
    </style>
    <style>
        [_nghost-nyb-c35] .nav-tabs[_ngcontent-nyb-c35] .nav-item.disabled[_ngcontent-nyb-c35] a.disabled[_ngcontent-nyb-c35] {
            cursor: default
        }
    </style>
    <style>
        .betCounts[_ngcontent-nyb-c92] .matched[_ngcontent-nyb-c92],
        .betCounts[_ngcontent-nyb-c92] .unmatched[_ngcontent-nyb-c92] {
            min-width: 25px;
            width: auto;
            padding: 0 5px
        }

        .min-max[_ngcontent-nyb-c92] {
            float: right;
            color: #ef4e46;
            font-size: 13px;
            padding: 12px;
            font-weight: 700;
            text-transform: capitalize
        }

        .min-max[_ngcontent-nyb-c92] span[_ngcontent-nyb-c92] {
            margin-right: 5px
        }

        .position-relative[_ngcontent-nyb-c92] {
            position: relative
        }

        .event-title[_ngcontent-nyb-c92] {
            display: flex;
            justify-content: space-between
        }

        .mobile-sec[_ngcontent-nyb-c92] {
            position: relative
        }

        .mobile-sec[_ngcontent-nyb-c92] a.tv[_ngcontent-nyb-c92] {
            top: 9px
        }

        .mobile-sec[_ngcontent-nyb-c92] a.tv[_ngcontent-nyb-c92] i[_ngcontent-nyb-c92] {
            color: #464646
        }

        .no-dt[_ngcontent-nyb-c92] {
            background: #f2f2f2;
            border-bottom: 1px solid #fff;
            text-align: center
        }

        .no-dt[_ngcontent-nyb-c92] p[_ngcontent-nyb-c92] {
            padding: 5px 0;
            margin: 0
        }

        .mobile-sec[_ngcontent-nyb-c92] a.tv[_ngcontent-nyb-c92] {
            position: absolute;
            top: 10px;
            right: 0
        }

        .mobile-sec[_ngcontent-nyb-c92] a.tv[_ngcontent-nyb-c92] i[_ngcontent-nyb-c92] {
            font-weight: bolder;
            color: #fff
        }

        .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] {
            padding-top: 3px;
            padding-bottom: 3px
        }

        .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] label[_ngcontent-nyb-c92] {
            display: flex;
            flex-wrap: wrap;
            align-items: flex-start;
            font-size: var(--font-body)
        }

        .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] label[_ngcontent-nyb-c92] img[_ngcontent-nyb-c92] {
            height: 25px;
            margin-right: 5px;
            border-radius: 2px
        }

        .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] label[_ngcontent-nyb-c92] div[_ngcontent-nyb-c92]:last-child {
            width: calc(100% - 50px);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between
        }

        .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] label[_ngcontent-nyb-c92] div[_ngcontent-nyb-c92]:last-child>span[_ngcontent-nyb-c92]:first-child {
            font-weight: 700;
            float: left;
            width: 100%
        }

        .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] label[_ngcontent-nyb-c92] .jockey-detail[_ngcontent-nyb-c92] {
            font-size: 14px;
            margin-top: 0;
            flex-wrap: wrap;
            max-width: calc(100% - 70px)
        }

        .horse-time-detail[_ngcontent-nyb-c92] {
            display: flex;
            flex-wrap: wrap;
            padding: 5px 5px 0
        }

        .horse-time-detail[_ngcontent-nyb-c92] a[_ngcontent-nyb-c92] {
            display: flex
        }

        .horse-time-detail[_ngcontent-nyb-c92] span[_ngcontent-nyb-c92] {
            background: var(--theme2-bg);
            color: var(--secondary-color);
            padding: 5px 10px;
            border-radius: 4px;
            margin-right: 5px;
            margin-bottom: 5px;
            cursor: pointer;
            position: relative;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            -ms-border-radius: 4px;
            -o-border-radius: 4px
        }

        .horse-time-detail[_ngcontent-nyb-c92] span.active[_ngcontent-nyb-c92] {
            position: relative
        }

        .horse-time-detail[_ngcontent-nyb-c92] span.active[_ngcontent-nyb-c92]:before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            border-right: 10px solid #0000;
            border-top: 10px solid green
        }

        .horse-detail[_ngcontent-nyb-c92] .suspended[_ngcontent-nyb-c92]:after {
            content: attr(data-title);
            font-size: 16px;
            color: red;
            font-family: Arial, Verdana, Helvetica, sans-serif;
            width: 60%
        }

        .horse-detail[_ngcontent-nyb-c92] .horse-attr[_ngcontent-nyb-c92] {
            background: #ebe7e7;
            border: 1px solid #ccc;
            padding: 1px;
            font-size: 12px;
            margin-left: 2px;
            border-radius: 4px;
            color: #333;
            margin-bottom: 1px;
            font-weight: 400
        }

        .horse-detail[_ngcontent-nyb-c92] .table-row[_ngcontent-nyb-c92] .box-1[_ngcontent-nyb-c92] {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            flex-direction: column
        }

        .horse-detail[_ngcontent-nyb-c92] .custom-checkbox[_ngcontent-nyb-c92] .custom-control-label[_ngcontent-nyb-c92]:before {
            border-radius: .25rem;
            background: #ddd
        }

        .horse-detail[_ngcontent-nyb-c92] .Lay_oddsbox[_ngcontent-nyb-c92],
        .horse-detail[_ngcontent-nyb-c92] .back_oddsbox[_ngcontent-nyb-c92] {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            flex-direction: column
        }

        .nav-item[_ngcontent-nyb-c92] {
            width: 33.33% !important
        }

        @media (min-width: 767px) {
            .d-none-desktop[_ngcontent-nyb-c92] {
                display: none
            }
        }

        @media (max-width: 767px) {
            .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] label[_ngcontent-nyb-c92] .jockey-detail[_ngcontent-nyb-c92] {
                font-size: 14px;
                margin-top: 0;
                max-width: 100%
            }

            .horse-detail[_ngcontent-nyb-c92] .horse-attr[_ngcontent-nyb-c92] {
                font-size: 10px
            }

            .horse-detail.d-none-desktop[_ngcontent-nyb-c92] {
                display: inline-flex;
                margin-bottom: 2px
            }

            .d-none-mobile[_ngcontent-nyb-c92] {
                display: none
            }

            .horse-detail[_ngcontent-nyb-c92] .country-name[_ngcontent-nyb-c92] label[_ngcontent-nyb-c92] div[_ngcontent-nyb-c92]:last-child>span[_ngcontent-nyb-c92]:first-child {
                margin-bottom: 1px
            }
        }
    </style>
    <style>
        input[_ngcontent-nyb-c88]::-webkit-inner-spin-button,
        input[_ngcontent-nyb-c88]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0
        }

        input[type=number][_ngcontent-nyb-c88] {
            -moz-appearance: textfield
        }

        #overlay[_ngcontent-nyb-c88] {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #000000d9;
            background-color: #00000080;
            z-index: 2;
            color: #807e7e
        }

        .bet-slip-container[_ngcontent-nyb-c88] {
            position: relative
        }

        .bet-input.lay-border[_ngcontent-nyb-c88]:before {
            background-color: #f994ba;
            background-image: linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(var(--bg-table-header), var(--bg-table-header))
        }

        @media (max-width: 767px) {

            button[_ngcontent-nyb-c88],
            input[_ngcontent-nyb-c88] {
                height: 28px !important;
                line-height: normal !important
            }
        }
    </style>
    <style>
        .scorecard-row[_ngcontent-nyb-c90] .row5[_ngcontent-nyb-c90] .col-6[_ngcontent-nyb-c90]:last-child {
            text-align: right
        }

        .bold[_ngcontent-nyb-c90] {
            font-weight: 400
        }

        body[_ngcontent-nyb-c90] {
            display: flex;
            justify-content: center
        }

        .widgets[_ngcontent-nyb-c90] {
            width: 100%
        }

        .sr-widget[_ngcontent-nyb-c90] {
            border: 1px solid #0000001f;
            margin-bottom: 24px
        }

        .sr-widget-title[_ngcontent-nyb-c90] {
            font-weight: 700;
            padding-bottom: 4px
        }

        .ball-runs[_ngcontent-nyb-c90] {
            display: inline-block;
            height: 25px;
            width: 25px;
            line-height: 25px;
            align-items: center;
            text-align: center;
            border-radius: 100px;
            padding: 0
        }

        .ball123[_ngcontent-nyb-c90] {
            background-color: #48a23c
        }

        .ball0[_ngcontent-nyb-c90] {
            background-color: #999
        }

        .ball45[_ngcontent-nyb-c90] {
            background-color: #66b2ff
        }

        .ballNo[_ngcontent-nyb-c90] {
            background-color: #c2ad7b
        }

        .ballw[_ngcontent-nyb-c90] {
            background-color: #c9362b
        }

        .ball6[_ngcontent-nyb-c90] {
            background-color: #883997
        }

        .ball[_ngcontent-nyb-c90] {
            background-color: #087f23
        }

        .team-score[_ngcontent-nyb-c90] {
            display: flex;
            align-items: center;
            justify-content: space-between
        }

        .required-run[_ngcontent-nyb-c90] {
            color: #c8bfbf
        }

        @media (max-width: 767px) {
            .ball-runs[_ngcontent-nyb-c90] {
                height: 17px;
                width: 17px;
                line-height: 17px
            }
        }
    </style>
</head>

<body class="" style="padding-right: 0px;">
    <app-root _nghost-nyb-c12="" ng-version="12.1.5"><router-outlet _ngcontent-nyb-c12=""></router-outlet><app-login _nghost-nyb-c73="">
            <div class="login">
                <div class="wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="loginInner1">
                                    <div class="log-logo m-b-20 text-center"><img class="logo-login-1" src="{{asset('/login/')}}/logo.png"><!----><!----></div>
                                    <div class="featured-box-login featured-box-secundary default">
                                        <h4 class="text-center"> LOGIN <i class="fa fa-hand-point-down"></i></h4>
                                        <form class="mt-2" id="loginForm">
                                        @csrf
                                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" >
                                       
                        <input type="password" class="form-control mt-2" id="password" name="password" placeholder="Password" >
                        

                                            <div class="form-group text-center mt-2"><button _ngcontent-nyb-c73="" type="submit" class="btn btn-submit btn-login"> Login <i class="ml-2 fa fa-sign-in-alt"></i><!----><!----></button></div><small _ngcontent-nyb-c73="" class="recaptchaTerms"> This site is protected by reCAPTCHA and the Google <a _ngcontent-nyb-c73="" href="javascript:void(0)"> Privacy Policy</a> and <a _ngcontent-nyb-c73="" href="javascript:void(0)"> Terms of Service</a> apply. </small>
                                            <div class="mt-2 text-center download-apk">
                                                <p _ngcontent-nyb-c73="" class="mt-1 mb-0"><!----></p>
                                            </div>
                                        </form>
                                        
                                        
                                    </div><!----><!---->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </app-login><!---->
    </app-root>


     <!-- login Modal -->
  <div class="modal fade" id="loginexampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content login_wid">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Please Confirm</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <P>Underage gambling is prohibited. Please confirm if you are 18 years old and above as of today</P>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn Exit_red" data-bs-dismiss="modal">Exit</button>
                    <button type="button" class="btn btn-primary Confirm_other">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Hide the error message initially
            $('#usernameError').hide();
    
            // Intercept form submission
            $('#loginForm').submit(function(event) {
                event.preventDefault(); // Prevent the form from submitting the traditional way
    
                // Reset the previous error message
                $('#usernameError').text('');
    
                // Perform form validation here
                var username = $('#username').val();
                var password = $('#password').val();
                if (username.trim() === '' && password.trim() === '') {
                    showFlashMessage('Please fill Username and Password');
                    return;
                }
                // Check if username and password are empty
                if (username.trim() === '') {
                    showFlashMessage('The Username field is required');
                    return;
                }
    
                if (password.trim() === '') {
                    showFlashMessage('The Password field is required');
                    return;
                }
    
                // Display the modal if the form is valid
                $('#loginexampleModal').modal('show');
            });
    
            // Handle modal confirmation button click
            $('#loginexampleModal .btn-primary').click(function() {
                // Get form data
                var formData = $('#loginForm').serialize();
    
                // Submit form data to the 'login_submit' route using AJAX
                $.ajax({
                    type: 'POST',
                    url: '{{ route('login_submit') }}',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            // Redirect on success
                            window.location.href = response.redirect;
                        } else if (response.message) {
                            // Handle failure, show error message in flash
                            showFlashMessage(response.message);
    
                            // Set a separate timeout for incorrect login attempts
                            setTimeout(function() {
                                $('#usernameError').removeClass('flash__wrapper').hide();
                            }, 3000); // Adjust the timeout as needed for incorrect attempts
                        }
                    },
                    error: function(error) {
                        // Handle the AJAX error
                        console.error(error);
                        alert('An error occurred. Please try again.');
                    }
                });
    
                // Close the modal
                $('#loginexampleModal').modal('hide');
            });
    
            function showFlashMessage(message) {
                // Set flash message content
                $('#usernameError').text(message);
    
                // Show the flash message
                $('#usernameError').show().addClass('flash__wrapper');
    
                // Set a timeout to hide the flash message after 3 seconds
                setTimeout(function() {
                    $('#usernameError').removeClass('flash__wrapper').hide();
                }, 2000);
            }
        });
    </script>
</body>

</html>