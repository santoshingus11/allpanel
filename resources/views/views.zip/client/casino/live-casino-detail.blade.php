<!DOCTYPE html>
<!-- saved from url=(0054)https://crickekbuz.art/exchange-game/1444001/67580 -->
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>CRICKET247BUZZ</title>
    <!--<base href="/">-->
    <base href=".">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
    <meta content="" name="description">
    <meta content="" name="keywords">
    <link rel="icon" type="image/x-icon" href="https://crickekbuz.art/favicon.ico">
    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->

    <!-- Google Fonts -->
    <style type="text/css">
        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYNNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoadNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYdNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoY9NZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobdNZUSdy4Q.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAgM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLCwM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAwM9QPFUex17.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDAM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAAM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAQM9QPFUex17.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDwM9QPFUew.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYNNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoadNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYdNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYtNZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoY9NZUSdy4ehI.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: italic;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobdNZUSdy4Q.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCkYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCAYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCgYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCcYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCsYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCoYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 300;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCQYb9lecyU.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19-7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19a7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1967DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19G7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1927DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19y7DQk6YvNkeg.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19K7DQk6YvM.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCkYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCAYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCgYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+1F00-1FFF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCcYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0370-03FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCsYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCoYb9lecyVC4A.woff2) format('woff2');
            unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
        }

        @font-face {
            font-family: 'Roboto Condensed';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCQYb9lecyU.woff2) format('woff2');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
    </style>

    <!-- assets CSS Files -->
    <style>
        :root {
            --blue: #007bff;
            --indigo: #6610f2;
            --purple: #6f42c1;
            --pink: #e83e8c;
            --red: #dc3545;
            --orange: #fd7e14;
            --yellow: #ffc107;
            --green: #28a745;
            --teal: #20c997;
            --cyan: #17a2b8;
            --white: #fff;
            --gray: #6c757d;
            --gray-dark: #343a40;
            --primary: #007bff;
            --secondary: #6c757d;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --breakpoint-xs: 0;
            --breakpoint-sm: 576px;
            --breakpoint-md: 768px;
            --breakpoint-lg: 992px;
            --breakpoint-xl: 1200px;
            --font-family-sans-serif: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            --font-family-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        }

        *,
        ::after,
        ::before {
            box-sizing: border-box;
        }

        html {
            font-family: sans-serif;
            line-height: 1.15;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            margin: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            text-align: left;
            background-color: #fff;
        }

        @media print {

            *,
            ::after,
            ::before {
                text-shadow: none !important;
                box-shadow: none !important;
            }

            @page {
                size: a3;
            }

            body {
                min-width: 992px !important;
            }
        }
    </style>
    <link href="https://crickekbuz.art/public/assets/bootstrap.min.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    </noscript>
    <link rel="stylesheet" href="https://crickekbuz.art/public/assets/bs-datepicker.css">
    <link href="https://crickekbuz.art/public/assets/card-characters" rel="stylesheet">

    <style>
        @import url('https://fonts.cdnfonts.com/css/card-characters');

        .card-icon {
            font-family: Card Characters;
            width: 24px;
            text-align: right;
            display: inline-block;
        }

        .card-red {
            color: #ff0000;
        }

        .card-black {
            color: #000000;
        }
    </style>



    <!-- Template Main CSS File -->
    <link rel="stylesheet" href="https://crickekbuz.art/public/assets/theme.css" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/theme.css">
    </noscript>
    <style>
        @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css");

        body {
            font-family: "Roboto Condensed", sans-serif !important;
            color: #272829;
        }

        @media (max-width: 767px) {}
    </style>
    <link href="https://crickekbuz.art/public/assets/style.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/style.css">
    </noscript>
    <link href="https://crickekbuz.art/public/assets/casinos.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/casinos.css">
    </noscript>
    <style>
        @import url("https://use.fontawesome.com/releases/v5.0.10/css/all.css");

        body {
            font-family: 'Roboto Condensed', sans-serif !important;
            color: #272829;
        }
    </style>
    <link href="https://crickekbuz.art/public/assets/login.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
    <noscript>
        <link rel="stylesheet" href="assets/css/login.css">
    </noscript>
    <script>
        const hosts = [{
                domain: "localhost",
                description: "Bet with the most trusted online betting exchange in India. Get the best odds, instant withdrawals & deposits, 24/7 customer service and refer bonus. Sign up now!",
            },
            {
                domain: "funexch.net",
                description: "Register Now On India's 1st Licensed Online Casino And Sportsbook. Experience 24/7 Customer Service, Auto Deposit/withdrawal, And 1000+ Live Casino Games & Sports Betting Games. Enjoy 6% Bonus On Every Deposit!"
            }

        ];
        const host = hosts?.find((host) => host?.domain === window.location.hostname);
        if (host) {
            const newMetaTag = document.createElement("meta");
            newMetaTag.name = "description";
            newMetaTag.content = host?.description;
            if (document.querySelector("meta[name='description']")) {
                document.querySelector("meta[name='description']").replaceWith(newMetaTag);
            } else {
                document.head.appendChild(newMetaTag);
            }
        }
    </script>

    <script src="https://crickekbuz.art/public/assets/jquery-3.5.1.min.js.download"></script>

    <script src="https://crickekbuz.art/public/assets/jquery.min.js.download"></script>
    <script src="https://crickekbuz.art/public/assets/bootstrap.bundle.min.js.download"></script>
    <script type="text/javascript" src="https://crickekbuz.art/public/assets/jquery.dataTables.min.js.download"></script>
    <script type="text/javascript" src="https://crickekbuz.art/public/assets/dataTables.bootstrap4.min.js.download"></script>
    <style>
        @charset "UTF-8";

        :root {
            --bs-blue: #0d6efd;
            --bs-indigo: #6610f2;
            --bs-purple: #6f42c1;
            --bs-pink: #d63384;
            --bs-red: #dc3545;
            --bs-orange: #fd7e14;
            --bs-yellow: #ffc107;
            --bs-green: #198754;
            --bs-teal: #20c997;
            --bs-cyan: #0dcaf0;
            --bs-black: #000;
            --bs-white: #fff;
            --bs-gray: #6c757d;
            --bs-gray-dark: #343a40;
            --bs-gray-100: #f8f9fa;
            --bs-gray-200: #e9ecef;
            --bs-gray-300: #dee2e6;
            --bs-gray-400: #ced4da;
            --bs-gray-500: #adb5bd;
            --bs-gray-600: #6c757d;
            --bs-gray-700: #495057;
            --bs-gray-800: #343a40;
            --bs-gray-900: #212529;
            --bs-primary: #0d6efd;
            --bs-secondary: #6c757d;
            --bs-success: #198754;
            --bs-info: #0dcaf0;
            --bs-warning: #ffc107;
            --bs-danger: #dc3545;
            --bs-light: #f8f9fa;
            --bs-dark: #212529;
            --bs-primary-rgb: 13, 110, 253;
            --bs-secondary-rgb: 108, 117, 125;
            --bs-success-rgb: 25, 135, 84;
            --bs-info-rgb: 13, 202, 240;
            --bs-warning-rgb: 255, 193, 7;
            --bs-danger-rgb: 220, 53, 69;
            --bs-light-rgb: 248, 249, 250;
            --bs-dark-rgb: 33, 37, 41;
            --bs-white-rgb: 255, 255, 255;
            --bs-black-rgb: 0, 0, 0;
            --bs-body-color-rgb: 33, 37, 41;
            --bs-body-bg-rgb: 255, 255, 255;
            --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            --bs-gradient: linear-gradient(180deg, #ffffff26, #fff0);
            --bs-body-font-family: var(--bs-font-sans-serif);
            --bs-body-font-size: 1rem;
            --bs-body-font-weight: 400;
            --bs-body-line-height: 1.5;
            --bs-body-color: #212529;
            --bs-body-bg: #fff;
            --bs-border-width: 1px;
            --bs-border-style: solid;
            --bs-border-color: #dee2e6;
            --bs-border-color-translucent: rgba(0, 0, 0, .175);
            --bs-border-radius: 0.375rem;
            --bs-border-radius-sm: 0.25rem;
            --bs-border-radius-lg: 0.5rem;
            --bs-border-radius-xl: 1rem;
            --bs-border-radius-2xl: 2rem;
            --bs-border-radius-pill: 50rem;
            --bs-link-color: #0d6efd;
            --bs-link-hover-color: #0a58ca;
            --bs-code-color: #d63384;
            --bs-highlight-bg: #fff3cd;
        }

        *,
        :after,
        :before {
            box-sizing: border-box;
        }

        @media (prefers-reduced-motion:no-preference) {
            :root {
                scroll-behavior: smooth;
            }
        }

        body {
            margin: 0;
            font-family: var(--bs-body-font-family);
            font-size: var(--bs-body-font-size);
            font-weight: var(--bs-body-font-weight);
            line-height: var(--bs-body-line-height);
            color: var(--bs-body-color);
            text-align: var(--bs-body-text-align);
            background-color: var(--bs-body-bg);
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }
    </style>
    <link rel="stylesheet" href="https://crickekbuz.art/public/assets/styles.1f3b1d3fc8356a080acf.css" media="all" onload="this.media=&#39;all&#39;"><noscript>
        <link rel="stylesheet" href="styles.1f3b1d3fc8356a080acf.css">
    </noscript>
    <style type="text/css">
        #_copy {
            align-items: center;
            background: #4494d5;
            border-radius: 3px;
            color: #fff;
            cursor: pointer;
            display: flex;
            font-size: 13px;
            height: 30px;
            justify-content: center;
            position: absolute;
            width: 60px;
            z-index: 1000
        }

        #select-tooltip,
        #sfModal,
        .modal-backdrop,
        div[id^=reader-helper] {
            display: none !important
        }

        .modal-open {
            overflow: auto !important
        }

        ._sf_adjust_body {
            padding-right: 0 !important
        }

        .super_copy_btns_div {
            position: fixed;
            width: 154px;
            left: 10px;
            top: 45%;
            background: #e7f1ff;
            border: 2px solid #4595d5;
            font-weight: 600;
            border-radius: 2px;
            font-family: -apple-system, BlinkMacSystemFont, Segoe UI, PingFang SC, Hiragino Sans GB, Microsoft YaHei, Helvetica Neue, Helvetica, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol;
            z-index: 5000
        }

        .super_copy_btns_logo {
            width: 100%;
            background: #4595d5;
            text-align: center;
            font-size: 12px;
            color: #e7f1ff;
            line-height: 30px;
            height: 30px
        }

        .super_copy_btns_btn {
            display: block;
            width: 128px;
            height: 28px;
            background: #7f5711;
            border-radius: 4px;
            color: #fff;
            font-size: 12px;
            border: 0;
            outline: 0;
            margin: 8px auto;
            font-weight: 700;
            cursor: pointer;
            opacity: .9
        }

        .super_copy_btns_btn:hover {
            opacity: .8
        }

        .super_copy_btns_btn:active {
            opacity: 1
        }
    </style>
    <style></style>
    <style>
        :root {
            --primary: #2d3387;
            --secondary: #092844;
            --third: #2b329bE6;
            --forth: #092844D9;
            --fifth: #fff;
            --heading-text-color: #fff;
            --active-heading-text-color: #fff;
            --bet-btn: #28a745;
            --stake-btn: #092844;
            --login1: #2b329b;
            --login2: #092844
        }
    </style>
    <style>
        .flex-grid[_ngcontent-wey-c75] {
            display: flex;
            text-align: center;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 18px;
            color: #fff;
            padding: 0;
            width: 100%;
            margin: 0
        }

        .flex-child[_ngcontent-wey-c75] {
            width: 50%;
            text-align: center;
            background-color: #bb1919
        }

        .flex-child[_ngcontent-wey-c75]:nth-child(2) {
            background-color: #8a1538
        }

        .flex-child__content[_ngcontent-wey-c75] {
            display: inline-block;
            background-color: initial;
            width: 100%;
            text-align: center
        }

        .top-nav-event[_ngcontent-wey-c75] {
            background: #1a5684 !important;
            scrollbar-width: 0 !important
        }

        .top-nav-event[_ngcontent-wey-c75]::webkit-scrollbar {
            width: 0 !important;
            background: #0000 !important;
            display: none !important
        }

        .bg-color[_ngcontent-wey-c75] {
            background: #101450 !important
        }
    </style>
    <style>
        b[_ngcontent-wey-c72] {
            font-weight: 400 !important
        }

        .searchAnchor[_ngcontent-wey-c72] {
            color: #000 !important
        }

        .searchAnchor[_ngcontent-wey-c72]:hover {
            color: #fff !important
        }

        .game-date[_ngcontent-wey-c72],
        .search-game-name[_ngcontent-wey-c72] {
            float: left;
            width: 50%
        }

        .game-teams[_ngcontent-wey-c72] {
            width: 100%;
            float: left
        }

        .searchM[_ngcontent-wey-c72] .search[_ngcontent-wey-c72] {
            position: absolute;
            margin: auto;
            top: 0;
            right: 0;
            bottom: 0;
            left: 8px;
            width: 30px;
            height: 30px;
            background: #fff;
            border-radius: 50%;
            transition: all 1s;
            z-index: 4;
            text-align: center;
            line-height: 30px
        }

        .searchM[_ngcontent-wey-c72] .search[_ngcontent-wey-c72]:hover {
            cursor: pointer
        }

        .searchM[_ngcontent-wey-c72] input[_ngcontent-wey-c72] {
            position: absolute;
            margin: auto;
            text-align: left;
            top: 0;
            right: 0;
            bottom: 0;
            left: 8px;
            width: auto;
            height: 30px;
            outline: none;
            border: none;
            background: #fff;
            color: #000;
            border-radius: 30px;
            transition: all 1s;
            opacity: 0;
            z-index: 5;
            font-weight: bolder
        }

        .searchM[_ngcontent-wey-c72] input[_ngcontent-wey-c72]:hover {
            cursor: pointer
        }

        .searchM[_ngcontent-wey-c72] input[_ngcontent-wey-c72]:focus {
            width: 200px;
            opacity: 1;
            cursor: text
        }

        .searchM[_ngcontent-wey-c72] input[_ngcontent-wey-c72]:focus~.search[_ngcontent-wey-c72] {
            right: -360px;
            background: #fff;
            z-index: 6
        }

        .searchM[_ngcontent-wey-c72] input[_ngcontent-wey-c72]:focus~.search[_ngcontent-wey-c72]:before {
            top: 0;
            left: 0;
            width: 25px
        }

        .searchM[_ngcontent-wey-c72] input[_ngcontent-wey-c72]:focus~.search[_ngcontent-wey-c72]:after {
            top: 0;
            left: 0;
            width: 25px;
            height: 2px;
            border: none;
            background: #fff;
            border-radius: 0;
            transform: rotate(-45deg)
        }

        .searchM[_ngcontent-wey-c72] input[_ngcontent-wey-c72]::placeholder {
            color: #000;
            opacity: .5;
            font-weight: bolder
        }
    </style>
    <style>
        .collapse[_ngcontent-wey-c73] {
            cursor: pointer
        }
    </style>
    <style>
        .c_odds_title[_ngcontent-wey-c115] .back[_ngcontent-wey-c115],
        .c_odds_value[_ngcontent-wey-c115] .back[_ngcontent-wey-c115] {
            border-right: 1px solid #fff
        }

        .c_odds_title[_ngcontent-wey-c115] .back[_ngcontent-wey-c115] {
            width: 100%
        }

        .teenpattiTest[_ngcontent-wey-c115] {
            width: 15.66%
        }

        .teenpattiTest[_ngcontent-wey-c115] .back[_ngcontent-wey-c115] {
            width: 100%
        }

        .casino_odds[_ngcontent-wey-c115] .row[_ngcontent-wey-c115] .col-md-5[_ngcontent-wey-c115],
        .row[_ngcontent-wey-c115]>*[_ngcontent-wey-c115] {
            padding: 0
        }

        .casino_odds[_ngcontent-wey-c115] .row[_ngcontent-wey-c115] .col-md-5[_ngcontent-wey-c115]:first-child span[_ngcontent-wey-c115] {
            margin-left: 5px
        }

        .casino-result-cards-item[_ngcontent-wey-c115] img[_ngcontent-wey-c115] {
            width: 30px
        }

        .casino-video-cards-container[_ngcontent-wey-c115] img[_ngcontent-wey-c115] {
            border: 1px solid #ff0;
            width: 28px
        }

        .casino-video-cards-container[_ngcontent-wey-c115] div[_ngcontent-wey-c115] h5[_ngcontent-wey-c115] {
            text-transform: uppercase;
            color: #fff;
            font-size: 14px;
            margin: 0;
            display: block;
            font-weight: 600
        }

        .casino-result-content-item[_ngcontent-wey-c115] {
            width: 32%
        }

        .casino-result-content[_ngcontent-wey-c115]:before {
            display: none
        }

        .casino-result-content[_ngcontent-wey-c115] .casino-result-content-item[_ngcontent-wey-c115] {
            border-right: 1px solid #5c5c5c
        }

        .casino-result-content[_ngcontent-wey-c115] .casino-result-content-item[_ngcontent-wey-c115]:last-child {
            border: none
        }

        .casino-result-cards[_ngcontent-wey-c115] h4[_ngcontent-wey-c115] {
            display: inline
        }

        .winner-icon[_ngcontent-wey-c115] {
            top: 10px
        }

        @media (max-width: 767px) {
            .winner-icon[_ngcontent-wey-c115] {
                top: 15px
            }

            .casino-result-content[_ngcontent-wey-c115] .casino-result-content-item[_ngcontent-wey-c115]:last-child,
            .casino-result-content-item[_ngcontent-wey-c115] {
                margin-bottom: 5px;
                width: 100%;
                padding: 5px;
                border: 1px solid #5c5c5c
            }

            .casino-result-content[_ngcontent-wey-c115] {
                justify-content: start
            }
        }
    </style>
    <style>
        .bets-section[_ngcontent-wey-c90] div[_ngcontent-wey-c90] {
            font-size: 12px;
            font-weight: 600
        }

        .bets-section[_ngcontent-wey-c90] input[_ngcontent-wey-c90] {
            height: 28px;
            background: #fff;
            border-radius: 0
        }

        .stakes[_ngcontent-wey-c90] .btn-group[_ngcontent-wey-c90] button[_ngcontent-wey-c90] {
            text-align: center;
            min-width: 16.5%;
            display: flex;
            width: 100%;
            margin: 3px 1px;
            padding: 2px;
            justify-content: center
        }

        .stakes[_ngcontent-wey-c90] .btn-group[_ngcontent-wey-c90] {
            width: 98%
        }

        .casino-place-bet[_ngcontent-wey-c90] {
            width: 100%;
            margin-bottom: 6px
        }

        .casino-place-bet-title[_ngcontent-wey-c90] {
            padding: 8px;
            text-transform: uppercase;
            font-weight: 700;
            background-color: #464646;
            color: #fff;
            font-size: 15px
        }

        .casino-place-bet-title[_ngcontent-wey-c90] .casino-min-max[_ngcontent-wey-c90] {
            text-transform: capitalize
        }

        .casino-place-bet-header[_ngcontent-wey-c90] {
            padding: 8px;
            background-color: #ccc;
            font-size: 12px;
            font-weight: 700;
            text-align: center;
            margin: 0
        }

        .casino-place-bet-box[_ngcontent-wey-c90],
        .casino-place-bet-header[_ngcontent-wey-c90] {
            display: flex;
            display: -webkit-flex;
            justify-content: space-between;
            color: #303030
        }

        .casino-place-bet-box[_ngcontent-wey-c90] {
            background-color: #f9f9f9;
            padding: 6px;
            flex-wrap: wrap
        }

        .casino-place-bet-info[_ngcontent-wey-c90] {
            display: flex;
            display: -webkit-flex;
            width: 100%;
            justify-content: space-between;
            align-items: center
        }

        .odds-box[_ngcontent-wey-c90] {
            position: relative;
            height: 40px;
            width: 80px;
            border: 1px solid #3c444b;
            border-radius: 4px;
            padding: 0;
            background-color: #3c444b
        }

        .odds-box[_ngcontent-wey-c90] input[_ngcontent-wey-c90] {
            color: #ced4da
        }

        input.form-control[_ngcontent-wey-c90]:disabled {
            cursor: not-allowed;
            background-color: initial
        }

        .odds-box[_ngcontent-wey-c90] .arrow-up[_ngcontent-wey-c90] {
            top: 9px;
            transform: scaleY(-1)
        }

        .odds-box[_ngcontent-wey-c90] .arrow-down[_ngcontent-wey-c90],
        .odds-box[_ngcontent-wey-c90] .arrow-up[_ngcontent-wey-c90] {
            position: absolute;
            right: 8px;
            width: auto;
            height: auto
        }

        .odds-box[_ngcontent-wey-c90] .arrow-down[_ngcontent-wey-c90] {
            bottom: 9px
        }

        .casino-place-bet-info[_ngcontent-wey-c90] .bet-input[_ngcontent-wey-c90] {
            width: 80px
        }

        .bet-input.back-border[_ngcontent-wey-c90],
        .bet-input.lay-border[_ngcontent-wey-c90] {
            border-left: 0
        }

        .bet-input[_ngcontent-wey-c90] {
            margin-top: 0;
            margin-left: 0;
            width: calc(48% - 8px);
            display: inline-block;
            vertical-align: top;
            position: relative;
            z-index: 0;
            overflow: hidden;
            height: 36px
        }

        .back-border[_ngcontent-wey-c90] {
            border-left: 5px solid #72bbef
        }

        .bet-input[_ngcontent-wey-c90] .form-control[_ngcontent-wey-c90] {
            color: #aaafb5;
            height: 36px;
            border: 0;
            background-color: initial
        }

        .bet-input.back-border[_ngcontent-wey-c90]:before {
            background-color: #72bbef;
            background-image: linear-gradient(#72bbef, #72bbef), linear-gradient(#72bbef, #72bbef), linear-gradient(#72bbef, #72bbef), linear-gradient(#3c444b, #3c444b)
        }

        .bet-input[_ngcontent-wey-c90]:before {
            content: "";
            position: absolute;
            z-index: -2;
            left: -50%;
            top: -50%;
            width: 200%;
            height: 200%;
            background-repeat: no-repeat;
            background-size: 50% 50%, 50% 50%;
            background-position: 0 0, 100% 0, 100% 100%, 0 100%;
            animation-name: rotateborder;
            animation-duration: 4s;
            animation-timing-function: linear;
            animation-iteration-count: infinite;
            -webkit-animation-name: rotateborder;
            -webkit-animation-duration: 4s;
            -webkit-animation-timing-function: linear;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-name: rotateborder;
            -moz-animation-duration: 4s;
            -moz-animation-timing-function: linear;
            -moz-animation-iteration-count: infinite
        }

        .bet-input[_ngcontent-wey-c90]:after {
            content: "";
            position: absolute;
            z-index: -1;
            left: 1px;
            top: 1px;
            width: calc(100% - 2px);
            height: calc(100% - 2px);
            background: #23292e;
            border-radius: 0;
            -webkit-transform: translateZ(0)
        }

        .casino-place-bet-button-container[_ngcontent-wey-c90] {
            display: flex;
            display: -webkit-flex;
            width: 100%;
            flex-wrap: wrap;
            margin-top: 6px
        }

        .casino-place-bet-button-container[_ngcontent-wey-c90] .btn[_ngcontent-wey-c90] {
            margin-right: 1%;
            margin-bottom: 1%;
            width: 24%;
            padding: 0
        }

        [type=button][_ngcontent-wey-c90]:not(:disabled),
        [type=reset][_ngcontent-wey-c90]:not(:disabled),
        [type=submit][_ngcontent-wey-c90]:not(:disabled),
        button[_ngcontent-wey-c90]:not(:disabled) {
            cursor: pointer
        }

        .btn-bet[_ngcontent-wey-c90] {
            height: 34px;
            background-color: #ccc;
            border-color: #0000;
            color: #303030 !important;
            font-size: 14px
        }

        .btn[_ngcontent-wey-c90] {
            box-shadow: none !important;
            height: auto;
            color: #fff;
            border-radius: 4px
        }

        .casino-place-bet-action-buttons[_ngcontent-wey-c90] {
            display: flex;
            display: -webkit-flex;
            justify-content: space-between;
            flex-wrap: wrap;
            width: 100%
        }

        .casino-place-bet-action-buttons[_ngcontent-wey-c90] .btn[_ngcontent-wey-c90] {
            height: 40px;
            width: 112px
        }

        .btn-reset[_ngcontent-wey-c90] {
            background-color: #fc4242;
            border-color: #fc4242
        }

        .bet-input.lay-border[_ngcontent-wey-c90]:before {
            background-color: #f994ba;
            background-image: linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(var(--bg-table-header), var(--bg-table-header))
        }

        button.btn.betplace-btn[_ngcontent-wey-c90] {
            height: 25px;
            line-height: 25px;
            min-height: 25px;
            padding: 0 !important
        }

        @media (max-width: 767px) {
            .stakes[_ngcontent-wey-c90] .btn-group[_ngcontent-wey-c90] {
                min-width: 100%;
                display: block
            }

            .stakes[_ngcontent-wey-c90] .btn-group[_ngcontent-wey-c90] button[_ngcontent-wey-c90] {
                width: 30%;
                margin: 5px
            }

            .bets-section[_ngcontent-wey-c90] h2[_ngcontent-wey-c90],
            .cancel-btn[_ngcontent-wey-c90] {
                display: none
            }
        }
    </style>
    <style>
        [_nghost-wey-c35] .nav-tabs[_ngcontent-wey-c35] .nav-item.disabled[_ngcontent-wey-c35] a.disabled[_ngcontent-wey-c35] {
            cursor: default
        }
    </style>
    <style>
        .text-custom[_ngcontent-wey-c78] {
            color: #fff
        }

        .loader[_ngcontent-wey-c78] {
            min-height: 100px;
            position: relative
        }

        #overlay[_ngcontent-wey-c78] {
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10;
            background-color: #000000e6
        }

        .dots-circle-spinner[_ngcontent-wey-c78] {
            display: inline-block;
            height: 1em;
            width: 1em;
            line-height: 1;
            vertical-align: middle;
            border-radius: 1em;
            transition: all .15s linear 0s;
            transform: scale(0);
            opacity: 0;
            box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
        }

        .dots-circle-spinner.loading[_ngcontent-wey-c78] {
            transform: scale(.5);
            opacity: 1;
            animation: dots-circle-rotation 1.5s linear .15s infinite normal forwards running
        }

        @keyframes dots-circle-rotation {
            to {
                box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
            }

            87.5% {
                box-shadow: 2em 0 0 -.4375em, 1.41421356em 1.41421356em 0 -.375em, 0 2em 0 -.3125em, -1.41421356em 1.41421356em 0 -.25em, -2em 0 0 -.1875em, -1.41421356em -1.41421356em 0 -.125em, 0 -2em 0 -.0625em, 1.41421356em -1.41421356em 0 0
            }

            75% {
                box-shadow: 2em 0 0 -.375em, 1.41421356em 1.41421356em 0 -.3125em, 0 2em 0 -.25em, -1.41421356em 1.41421356em 0 -.1875em, -2em 0 0 -.125em, -1.41421356em -1.41421356em 0 -.0625em, 0 -2em 0 0, 1.41421356em -1.41421356em 0 -.4375em
            }

            62.5% {
                box-shadow: 2em 0 0 -.3125em, 1.41421356em 1.41421356em 0 -.25em, 0 2em 0 -.1875em, -1.41421356em 1.41421356em 0 -.125em, -2em 0 0 -.0625em, -1.41421356em -1.41421356em 0 0, 0 -2em 0 -.4375em, 1.41421356em -1.41421356em 0 -.375em
            }

            50% {
                box-shadow: 2em 0 0 -.25em, 1.41421356em 1.41421356em 0 -.1875em, 0 2em 0 -.125em, -1.41421356em 1.41421356em 0 -.0625em, -2em 0 0 0, -1.41421356em -1.41421356em 0 -.4375em, 0 -2em 0 -.375em, 1.41421356em -1.41421356em 0 -.3125em
            }

            37.5% {
                box-shadow: 2em 0 0 -.1875em, 1.41421356em 1.41421356em 0 -.125em, 0 2em 0 -.0625em, -1.41421356em 1.41421356em 0 0, -2em 0 0 -.4375em, -1.41421356em -1.41421356em 0 -.375em, 0 -2em 0 -.3125em, 1.41421356em -1.41421356em 0 -.25em
            }

            25% {
                box-shadow: 2em 0 0 -.125em, 1.41421356em 1.41421356em 0 -.0625em, 0 2em 0 0, -1.41421356em 1.41421356em 0 -.4375em, -2em 0 0 -.375em, -1.41421356em -1.41421356em 0 -.3125em, 0 -2em 0 -.25em, 1.41421356em -1.41421356em 0 -.1875em
            }

            12.5% {
                box-shadow: 2em 0 0 -.0625em, 1.41421356em 1.41421356em 0 0, 0 2em 0 -.4375em, -1.41421356em 1.41421356em 0 -.375em, -2em 0 0 -.3125em, -1.41421356em -1.41421356em 0 -.25em, 0 -2em 0 -.1875em, 1.41421356em -1.41421356em 0 -.125em
            }

            0% {
                box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
            }
        }
    </style>
</head>

<body class="main-content-pages">
    <app-root _nghost-wey-c12="" ng-version="12.1.5"><router-outlet _ngcontent-wey-c12=""></router-outlet><app-layout _nghost-wey-c75=""><app-topnav _ngcontent-wey-c75="" _nghost-wey-c72="">
                <div _ngcontent-wey-c72="" class="topbar">
                    <div _ngcontent-wey-c72="" class="container-fluid">
                        <div _ngcontent-wey-c72="" class="row">
                            <div _ngcontent-wey-c72="" class="col-md-4 col-4 d-flex"><a _ngcontent-wey-c72="" routerlink="/sports/4" class="homelogo" href="https://crickekbuz.art/sports/4"><i _ngcontent-wey-c72="" class="fa fa-home"></i><img _ngcontent-wey-c72="" class="logo-login" src="https://crickekbuz.art/public/assets/logo2.png"><!----></a></div>
                            <div _ngcontent-wey-c72="" class="col-md-8 col-8">
                                <ul _ngcontent-wey-c72="" class="top-right">
                                    <li _ngcontent-wey-c72="" class="searchbar"><!----><input _ngcontent-wey-c72="" id="SearchInput" typeaheadoptionfield="name" placeholder="All Events" autocomplete="off" class="form-control ng-untouched ng-pristine ng-valid" style="display: none;" aria-expanded="false" aria-autocomplete="list"><!----><a _ngcontent-wey-c72="" href="javascript:void(0)"><i _ngcontent-wey-c72="" class="fa fa-search-plus"></i></a></li>
                                    <li _ngcontent-wey-c72="" class="rules-apk"><a _ngcontent-wey-c72="" routerlink="/rules" href="https://crickekbuz.art/rules"><b _ngcontent-wey-c72="">Rules</b></a></li>
                                    <li _ngcontent-wey-c72="" class="bespan"><span _ngcontent-wey-c72=""><sub _ngcontent-wey-c72="">Balance:</sub><i _ngcontent-wey-c72="" class="fa fa-landmark"></i><b _ngcontent-wey-c72="">1350</b></span><span _ngcontent-wey-c72="">Exp<sub _ngcontent-wey-c72="">osure</sub>: <b _ngcontent-wey-c72="">0</b></span></li>
                                    <li _ngcontent-wey-c72="" class="dropdown topright_drop">
                                        <div _ngcontent-wey-c72="" class="btn-group"><a _ngcontent-wey-c72="" href="https://crickekbuz.art/#" data-toggle="dropdown" class="dropdown-toggle">demo00 <i _ngcontent-wey-c72="" class="fa fa-caret-down"></i><i _ngcontent-wey-c72="" class="fa fa-chevron-down"></i></a>
                                            <div _ngcontent-wey-c72="" class="dropdown-menu dropdown-menu-right"><a _ngcontent-wey-c72="" routerlink="/reports/account-statement" class="dropdown-item" href="https://crickekbuz.art/reports/account-statement"> account statement </a><a _ngcontent-wey-c72="" routerlink="/reports/profit-loss" class="dropdown-item" href="https://crickekbuz.art/reports/profit-loss"> profit loss report </a><a _ngcontent-wey-c72="" routerlink="/reports/bet-history" class="dropdown-item" href="https://crickekbuz.art/reports/bet-history"> bet history </a><a _ngcontent-wey-c72="" routerlink="/reports/unsettled-bet" class="dropdown-item" href="https://crickekbuz.art/reports/unsettled-bet"> unsettled bet </a><a _ngcontent-wey-c72="" routerlink="/set-button-value" class="dropdown-item" href="https://crickekbuz.art/set-button-value"> set button values </a><a _ngcontent-wey-c72="" routerlink="/change-password" class="dropdown-item" href="https://crickekbuz.art/change-password"> change password </a><a _ngcontent-wey-c72="" routerlink="/rules" class="dropdown-item d-sm-none d-block" href="https://crickekbuz.art/rules"> rules </a>
                                                <div _ngcontent-wey-c72="" class="dropdown-divider"></div><a _ngcontent-wey-c72="" href="javascript:void(0)" class="dropdown-item"> SignOut </a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <marquee _ngcontent-wey-c72="" id="marquee_text" scrollamount="3" class="d-sm-block d-none"> </marquee>
                            </div>
                            <div _ngcontent-wey-c72="" class="col-12 d-block d-sm-none">
                                <div _ngcontent-wey-c72="" class="searchM"><!----><input _ngcontent-wey-c72="" type="text" placeholder="Search Here ..." typeaheadoptionfield="name" class="input ng-untouched ng-pristine ng-valid" aria-expanded="false" aria-autocomplete="list"><!---->
                                    <div _ngcontent-wey-c72="" class="search"><i _ngcontent-wey-c72="" class="fa fa-search"></i></div>
                                </div>
                                <marquee _ngcontent-wey-c72="" scrollamount="3" class="searchClose m-marquee"></marquee>
                            </div>
                        </div>
                    </div>
                </div><!---->
                <div _ngcontent-wey-c72="" class="header-bottom">
                    <div _ngcontent-wey-c72="" class="row mx-lg-0">
                        <div _ngcontent-wey-c72="" class="col-md-12">
                            <nav _ngcontent-wey-c72="" class="navbar navbar-expand-md btco-hover-menu"><button _ngcontent-wey-c72="" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler"><span _ngcontent-wey-c72="" class="navbar-toggler-icon"></span></button>
                                <div _ngcontent-wey-c72="" class="collapse navbar-collapse">
                                    <ul _ngcontent-wey-c72="" class="list-unstyled navbar-nav">
                                        <li _ngcontent-wey-c72="" class="nav-item active"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" routerlink="/sports/4" href="https://crickekbuz.art/sports/4"><b _ngcontent-wey-c72="">Home</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/sports/4"><b _ngcontent-wey-c72="">Cricket</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/sports/1"><b _ngcontent-wey-c72="">Football</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/sports/2"><b _ngcontent-wey-c72="">Tennis</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/sport-event/detail/2378962/240113031023"><b _ngcontent-wey-c72="">Election</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/sport-event/detail/4/28127348"><b _ngcontent-wey-c72="">IPL
                                                    2024</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/56767"><b _ngcontent-wey-c72="">One-Day
                                                    Teenpatti</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/98788"><b _ngcontent-wey-c72="">Roulette</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/98789"><b _ngcontent-wey-c72="">7 Up
                                                    &amp; Down</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/56967"><b _ngcontent-wey-c72="">32 Card
                                                    Casino</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/98566"><b _ngcontent-wey-c72="">Sicbo</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/67564"><b _ngcontent-wey-c72="">Poker</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/87564"><b _ngcontent-wey-c72="">Andar
                                                    Bahar</b></a></li>
                                        <li _ngcontent-wey-c72="" class="nav-item"><a _ngcontent-wey-c72="" routerlinkactive="router-link-exact-active router-link-active" href="https://crickekbuz.art/exchange-game/1444001/98790"><b _ngcontent-wey-c72="">One-Day
                                                    Dragon Tiger</b></a></li><!---->
                                    </ul><!---->
                                </div>
                            </nav>
                        </div>
                    </div>
                </div><!---->
                <div _ngcontent-wey-c72="" bsmodal="" tabindex="-1" role="dialog" aria-labelledby="dialog-static-name" class="modal fade">
                    <div _ngcontent-wey-c72="" class="modal-dialog modal-lg modal-lr">
                        <div _ngcontent-wey-c72="" class="modal-content">
                            <div _ngcontent-wey-c72="" class="modal-header"><button _ngcontent-wey-c72="" type="button" aria-label="Close" class="btn-close close pull-right"><i _ngcontent-wey-c72="" class="fa fa-close-thick"></i></button></div>
                            <div _ngcontent-wey-c72="" class="modal-body">
                                <div _ngcontent-wey-c72="" style="box-shadow: 0px 0px 5px; padding: 10px;">
                                    <h2 _ngcontent-wey-c72="">Dear Client,</h2>
                                    <h5 _ngcontent-wey-c72="" class="mb-1">You are requested to login with our official site <a _ngcontent-wey-c72="" href="javascript:void(0)">'cricket247buzz.com'</a><!----> only. Please check
                                        the site name before you login. </h5>
                                    <h5 _ngcontent-wey-c72="" class="mb-1">Thanks for your support.</h5>
                                    <h5 _ngcontent-wey-c72="" class="mb-1">Team cricket247buzz</h5><!---->
                                </div>
                                <div _ngcontent-wey-c72="" class="mt-5 font-hindi" style="box-shadow: 0px 0px 5px; padding: 10px;">
                                    <h2 _ngcontent-wey-c72="">प्रिय ग्राहक,</h2>
                                    <h5 _ngcontent-wey-c72="" class="mb-1">आपसे अनुरोध है कि केवल हमारी आधिकारिक साइट <a _ngcontent-wey-c72="" href="javascript:void(0)">'cricket247buzz.com'</a><!----> से लॉगिन करें।
                                        लॉगइन करने से पहले साइट का नाम जरूर देख लें।</h5>
                                    <h5 _ngcontent-wey-c72="" class="mb-1">आपके समर्थन के लिए धन्यवाद।</h5>
                                    <h5 _ngcontent-wey-c72="" class="mb-1">टीम cricket247buzz</h5><!---->
                                </div>
                                <div _ngcontent-wey-c72="" class="text-right mt-3"><button _ngcontent-wey-c72="" class="btn btn-primary" style="min-width: 100px;">OK</button></div>
                            </div>
                        </div>
                    </div>
                </div><!---->
            </app-topnav>
            <main _ngcontent-wey-c75="" id="main">
                <div _ngcontent-wey-c75="" class="row mx-0">
                    <div _ngcontent-wey-c75="" class="col-md-2 sidebar"><app-sidebar _ngcontent-wey-c75="" _nghost-wey-c73="">
                            <nav _ngcontent-wey-c73="" class="nav-menu">
                                <ul _ngcontent-wey-c73="">
                                    <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" data-toggle="collapse" href="https://crickekbuz.art/#SubsideMenu1" role="button" aria-expanded="true" aria-controls="SubsideMenu1" class="active"><span _ngcontent-wey-c73="">Casino</span><b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a>
                                        <div _ngcontent-wey-c73="" id="SubsideMenu1" class="collapse show">
                                            <ul _ngcontent-wey-c73=""><!----><!----></ul>
                                            <ul _ngcontent-wey-c73=""><!----><!----></ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Casino War
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Race 20-20
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Trio </span></a>
                                                </li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> The Trap
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Bollywood Casino
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Queen
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Teenpatti Test
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Baccarat
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Poker 2020
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Mulfis Teenpatti
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 2 Cards
                                                            Teenpatti </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Casino Meter
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Sicbo
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 1 Day Teenpatti
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 1 Day Poker
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Roulette
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 1 Day Dragon
                                                            Tiger </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Amar Akbar
                                                            Anthony </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Andar Bahar
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 7 Up &amp; Down
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Worli Matka
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Teenpatti T20
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 32 Card Casino
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Hi-Low
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Teenpatti
                                                            One-Day (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Teenpatti T20
                                                            (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 7 up &amp; down
                                                            (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> 32 Cards
                                                            (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Poker (Virtual)
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Six player poker
                                                            (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Andar Bahar
                                                            (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Matka (Virtual)
                                                        </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Roulette
                                                            (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Dragon Tiger
                                                            (Virtual) </span></a></li><!---->
                                            </ul>
                                            <ul _ngcontent-wey-c73=""><!---->
                                                <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73=""><span _ngcontent-wey-c73=""> Amar Akbar
                                                            Anthony (Virtual) </span></a></li><!---->
                                            </ul><!---->
                                        </div>
                                    </li><!---->
                                    <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" data-toggle="collapse" href="https://crickekbuz.art/#SubsideMenu2" role="button" aria-expanded="true" aria-controls="SubsideMenu1" class="active"><span _ngcontent-wey-c73="">Sports</span><b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a>
                                        <div _ngcontent-wey-c73="" id="SubsideMenu2" class="collapse show">
                                            <ul _ngcontent-wey-c73="">
                                                <li _ngcontent-wey-c73="">
                                                    <div _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu0">Cricket <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a>
                                                        <div _ngcontent-wey-c73="" class="collapse" id="SubMenu0">
                                                            <ul _ngcontent-wey-c73="">
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu00">Indian Premier League <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu00">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/28127348" routerlinkactive="active-menu"> Indian Premier League </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33244358" routerlinkactive="active-menu"> Sunrisers Hyderabad v Lucknow Super Giants
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33246936" routerlinkactive="active-menu"> Kolkata Knight Riders v Mumbai Indians </a>
                                                                            </li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33252847" routerlinkactive="active-menu"> Chennai Super Kings v Rajasthan Royals </a>
                                                                            </li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33244280" routerlinkactive="active-menu"> Punjab Kings v Royal Challengers Bengaluru
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33244304" routerlinkactive="active-menu"> Gujarat Titans v Chennai Super Kings </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33252848" routerlinkactive="active-menu"> Royal Challengers Bengaluru v Delhi Capitals
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33252860" routerlinkactive="active-menu"> Gujarat Titans v Kolkata Knight Riders </a>
                                                                            </li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33252133" routerlinkactive="active-menu"> Delhi Capitals v Lucknow Super Giants </a>
                                                                            </li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu01">Election <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu01">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/240113031023" routerlinkactive="active-menu"> BJP LS v CON LS </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu02">Cool
                                                                        and Smooth T10 <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu02">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49836657" routerlinkactive="active-menu"> Government Road Stingrays vs. Brownhill
                                                                                    Dolphins </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49836719" routerlinkactive="active-menu"> Haynes Smith Sharks vs. Sandy Point Snappers
                                                                                </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu03">T20
                                                                        Qosh Tepa National Cup <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu03">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49501201" routerlinkactive="active-menu"> Band-E-Amir Dragons vs. Mis-E-Ainak Knights
                                                                                </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu04">Womens International Twenty20 Matches
                                                                        <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu04">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33251361" routerlinkactive="active-menu"> Bangladesh Women v India Women </a></li>
                                                                            <!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu05">International Twenty20 Matches <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu05">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33254570" routerlinkactive="active-menu"> Bangladesh v Zimbabwe </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/33254631" routerlinkactive="active-menu"> Ireland v Pakistan </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu06">Big
                                                                        Bash League SRL <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu06">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708243" routerlinkactive="active-menu"> Perth Scorchers Srl vs. Hobart Hurricanes Srl
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708245" routerlinkactive="active-menu"> Sydney Sixers SRL vs. Melbourne Renegades Srl
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708247" routerlinkactive="active-menu"> Adelaide Strikers Srl vs. Hobart Hurricanes
                                                                                    Srl </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708249" routerlinkactive="active-menu"> Brisbane Heat Srl vs. Melbourne Renegades Srl
                                                                                </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu07">ECS
                                                                        Italy, Brescia <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu07">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49599107" routerlinkactive="active-menu"> Panjab vs. Trentino Aquila </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu08">SA
                                                                        T20 League SRL <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu08">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708677" routerlinkactive="active-menu"> Paarl Royals Srl vs. Sunrisers Eastern Cape
                                                                                    Srl </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708679" routerlinkactive="active-menu"> Joburg Super Kings Srl vs. Durban Super Giants
                                                                                    Srl </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708681" routerlinkactive="active-menu"> Paarl Royals Srl vs. Mi Cape Town Srl </a>
                                                                            </li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu09">Pakistan Super League SRL <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu09">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708553" routerlinkactive="active-menu"> Multan Sultans Srl vs. Quetta Gladiators Srl
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708555" routerlinkactive="active-menu"> Karachi Kings Srl vs. Islamabad United Srl
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708557" routerlinkactive="active-menu"> Multan Sultans Srl vs. Lahore Qalanders Srl
                                                                                </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu010">Inter Provincial Trophy <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu010">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49534385" routerlinkactive="active-menu"> Northern Knights vs. North-West Warriors </a>
                                                                            </li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu011">T20
                                                                        International SRL <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu011">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708979" routerlinkactive="active-menu"> Pakistan SRL vs. India SRL </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708981" routerlinkactive="active-menu"> England SRL vs. Australia SRL </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708983" routerlinkactive="active-menu"> Afghanistan Srl vs. West Indies Srl </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708985" routerlinkactive="active-menu"> South Africa SRL vs. India SRL </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708987" routerlinkactive="active-menu"> Sri Lanka Srl vs. New Zealand SRL </a></li>
                                                                            <!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu012">Caribbean Premier League SRL <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu012">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708385" routerlinkactive="active-menu"> St Kitts And Nevis Patriots Srl vs. Guyana
                                                                                    Amazon Warriors Srl </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708387" routerlinkactive="active-menu"> Barbados Royals Srl vs. Jamaica Tallawahs SRL
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708389" routerlinkactive="active-menu"> St Lucia Kings Srl vs. St Kitts And Nevis
                                                                                    Patriots Srl </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/4/49708391" routerlinkactive="active-menu"> Guyana Amazon Warriors Srl vs. Trinbago Knight
                                                                                    Riders SRL </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li><!---->
                                                            </ul>
                                                        </div>
                                                    </div><!---->
                                                </li>
                                                <li _ngcontent-wey-c73="">
                                                    <div _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu1">Football <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a>
                                                        <div _ngcontent-wey-c73="" class="collapse" id="SubMenu1">
                                                            <ul _ngcontent-wey-c73="">
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu10">UEFA
                                                                        Champions League SRL <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu10">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/49949659" routerlinkactive="active-menu"> Real Madrid SRL vs. Bayern Munich SRL </a>
                                                                            </li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu11">UEFA
                                                                        Europa Conference League <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu11">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242963" routerlinkactive="active-menu"> Club Brugge v Fiorentina </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu12">UEFA
                                                                        Champions League <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu12">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33237980" routerlinkactive="active-menu"> Real Madrid v Bayern Munich </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu13">UEFA
                                                                        Europa League <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu13">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242897" routerlinkactive="active-menu"> Atalanta v Marseille </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu14">German Bundesliga <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu14">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232196" routerlinkactive="active-menu"> Augsburg v Stuttgart </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232209" routerlinkactive="active-menu"> Freiburg v FC Heidenheim </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232244" routerlinkactive="active-menu"> RB Leipzig v Werder Bremen </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232224" routerlinkactive="active-menu"> FC Koln v Union Berlin </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232239" routerlinkactive="active-menu"> Mgladbach v Eintracht Frankfurt </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232199" routerlinkactive="active-menu"> Mainz v Dortmund </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232265" routerlinkactive="active-menu"> SV Darmstadt v Hoffenheim </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232269" routerlinkactive="active-menu"> Bayern Munich v Wolfsburg </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242791" routerlinkactive="active-menu"> Bochum v Leverkusen </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu15">Italian Serie A <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu15">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33243059" routerlinkactive="active-menu"> Frosinone v Inter </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232206" routerlinkactive="active-menu"> Fiorentina v AC Monza </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242806" routerlinkactive="active-menu"> Lecce v Udinese </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242813" routerlinkactive="active-menu"> Napoli v Bologna </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242387" routerlinkactive="active-menu"> AC Milan v Cagliari </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232263" routerlinkactive="active-menu"> Lazio v Empoli </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242667" routerlinkactive="active-menu"> Verona v Torino </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242683" routerlinkactive="active-menu"> Genoa v Sassuolo </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242549" routerlinkactive="active-menu"> Juventus v Salernitana </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232261" routerlinkactive="active-menu"> Atalanta v Roma </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu16">French Ligue 1 <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu16">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232192" routerlinkactive="active-menu"> Nice v Le Havre </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232638" routerlinkactive="active-menu"> Brest v Reims </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232334" routerlinkactive="active-menu"> Marseille v Lorient </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232355" routerlinkactive="active-menu"> Paris St-G v Toulouse </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232354" routerlinkactive="active-menu"> Nantes v Lille </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242805" routerlinkactive="active-menu"> Montpellier v Monaco </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232341" routerlinkactive="active-menu"> Clermont v Lyon </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232236" routerlinkactive="active-menu"> Strasbourg v Metz </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232270" routerlinkactive="active-menu"> Rennes v Lens </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33250509" routerlinkactive="active-menu"> Nice v Paris St-G </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu17">Spanish La Liga <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu17">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232277" routerlinkactive="active-menu"> Alaves v Girona </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232345" routerlinkactive="active-menu"> Mallorca v Las Palmas </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232340" routerlinkactive="active-menu"> Villarreal v Sevilla </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232267" routerlinkactive="active-menu"> Granada v Real Madrid </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232287" routerlinkactive="active-menu"> Athletic Bilbao v Osasuna </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232285" routerlinkactive="active-menu"> Cadiz v Getafe </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232282" routerlinkactive="active-menu"> Atletico Madrid v Celta Vigo </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232281" routerlinkactive="active-menu"> Valencia v Rayo Vallecano </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232286" routerlinkactive="active-menu"> Betis v Almeria </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232289" routerlinkactive="active-menu"> Barcelona v Real Sociedad </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu18">English League 2 <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu18">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33253089" routerlinkactive="active-menu"> Doncaster v Crewe </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu19">English Premier League <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu19">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232234" routerlinkactive="active-menu"> Fulham v Man City </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232260" routerlinkactive="active-menu"> Bournemouth v Brentford </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232254" routerlinkactive="active-menu"> West Ham v Luton </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232255" routerlinkactive="active-menu"> Everton v Sheff Utd </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232259" routerlinkactive="active-menu"> Tottenham v Burnley </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232222" routerlinkactive="active-menu"> Newcastle v Brighton </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232223" routerlinkactive="active-menu"> Wolves v Crystal Palace </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232221" routerlinkactive="active-menu"> Nottm Forest v Chelsea </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33242097" routerlinkactive="active-menu"> Man Utd v Arsenal </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33232351" routerlinkactive="active-menu"> Aston Villa v Liverpool </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu110">US
                                                                        Major League Football <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu110">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33233097" routerlinkactive="active-menu"> Philadelphia v Orlando City </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33249270" routerlinkactive="active-menu"> Philadelphia v New York City </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu111">German Cup <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu111">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33164647" routerlinkactive="active-menu"> Kaiserslautern v Leverkusen </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu112">French Cup <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu112">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33165611" routerlinkactive="active-menu"> Lyon v Paris St-G </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu113">UEFA Euro 2024 <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu113">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949254" routerlinkactive="active-menu"> Germany v Scotland </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949256" routerlinkactive="active-menu"> Hungary v Switzerland </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949282" routerlinkactive="active-menu"> Spain v Croatia </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949284" routerlinkactive="active-menu"> Italy v Albania </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/33143036" routerlinkactive="active-menu"> Poland v Netherlands </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949285" routerlinkactive="active-menu"> Slovenia v Denmark </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949287" routerlinkactive="active-menu"> Serbia v England </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949292" routerlinkactive="active-menu"> Belgium v Slovakia </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949297" routerlinkactive="active-menu"> Austria v France </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/32949298" routerlinkactive="active-menu"> Portugal v Czech Republic </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu114">Copa America <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu114">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023231" routerlinkactive="active-menu"> Argentina vs. Canada </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023233" routerlinkactive="active-menu"> Peru vs. Chile </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023489" routerlinkactive="active-menu"> Mexico vs. Jamaica </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023491" routerlinkactive="active-menu"> Ecuador vs. Venezuela </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023625" routerlinkactive="active-menu"> Uruguay vs. Panama </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023623" routerlinkactive="active-menu"> USA vs. Bolivia </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023761" routerlinkactive="active-menu"> Colombia vs. Paraguay </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/1/46023759" routerlinkactive="active-menu"> Brazil vs. Costa Rica </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li><!---->
                                                            </ul>
                                                        </div>
                                                    </div><!---->
                                                </li>
                                                <li _ngcontent-wey-c73="">
                                                    <div _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu2">Tennis <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a>
                                                        <div _ngcontent-wey-c73="" class="collapse" id="SubMenu2">
                                                            <ul _ngcontent-wey-c73="">
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu20">ATP
                                                                        Wuxi Challenger <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu20">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33254326" routerlinkactive="active-menu"> Remy Bertola v Rigele Te </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu21">WTA
                                                                        Rome 2024 <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu21">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33251965" routerlinkactive="active-menu"> Vekic v Tsurenko </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33251905" routerlinkactive="active-menu"> El Avanesyan v Bucsa </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255755" routerlinkactive="active-menu"> T Maria v Lin Fruhvirtova </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255765" routerlinkactive="active-menu"> Taylo Townsend v Bre Fruhvirtova </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255775" routerlinkactive="active-menu"> Dolehide v Pera </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33252009" routerlinkactive="active-menu"> D Parry v Blinkova </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255770" routerlinkactive="active-menu"> Karolina Schmiedlova v Aliaksandra Sasnovich
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33251975" routerlinkactive="active-menu"> N Osaka v Burel </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33252014" routerlinkactive="active-menu"> L Zhu v Mag Linette </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33252019" routerlinkactive="active-menu"> P Martic v M Sherif </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255786" routerlinkactive="active-menu"> Reb Masarova v I Begu </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33252004" routerlinkactive="active-menu"> K Siniakova v Nur Brancaccio </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33251999" routerlinkactive="active-menu"> Sof Kenin v L Bronzetti </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33252038" routerlinkactive="active-menu"> A Potapova v X Wang </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255781" routerlinkactive="active-menu"> Zarazua v El Cocciaretto </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33252028" routerlinkactive="active-menu"> Podoroska v Sorribes Tormo </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255813" routerlinkactive="active-menu"> Yaf Wang v Volynets </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255760" routerlinkactive="active-menu"> Di Sarra v V Gracheva </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255791" routerlinkactive="active-menu"> Sramkova v Pedone </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255803" routerlinkactive="active-menu"> D Saville v C Tauson </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu22">ATP
                                                                        Rome <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu22">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33254195" routerlinkactive="active-menu"> Zhizhen Zhang v Daniel Elahi Galan </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255143" routerlinkactive="active-menu"> Luciano Darderi v Denis Shapovalov </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255142" routerlinkactive="active-menu"> Jakub Mensik v Yannick Hanfmann </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255146" routerlinkactive="active-menu"> Nuno Borges v Pedro Martinez </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255148" routerlinkactive="active-menu"> Yoshihito Nishioka v Sebastian Ofner </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255979" routerlinkactive="active-menu"> Maximilian Marterer v Flavio Cobolli </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255015" routerlinkactive="active-menu"> Alexander Shevchenko v Fabian Marozsan </a>
                                                                            </li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255145" routerlinkactive="active-menu"> Pavel Kotov v Alex Michelsen </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255975" routerlinkactive="active-menu"> Thiago Monteiro v Gael Monfils </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255983" routerlinkactive="active-menu"> Diego Schwartzman v Aleksandar Vukic </a></li>
                                                                            <!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu23">ATP
                                                                        Francavilla Challenger <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu23">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33253153" routerlinkactive="active-menu"> Marco Cecchinato v Franco Agamenone </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33253152" routerlinkactive="active-menu"> Adrian Andreev v Andrea Pellegrino </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255036" routerlinkactive="active-menu"> Maks Kasnikowski v Nick Hardt </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255508" routerlinkactive="active-menu"> Ryan Nijboer v Federico Arnaboldi </a></li>
                                                                            <!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li>
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu24">ATP
                                                                        Mauthausen Challenger <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu24">
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255027" routerlinkactive="active-menu"> Francisco Comesana v Juan Manuel Cerundolo
                                                                                </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33254583" routerlinkactive="active-menu"> Filip Misolic v Ugo Blanchet </a></li><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255044" routerlinkactive="active-menu"> Otto Virtanen v Max Hans Rehberg </a></li>
                                                                            <!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!---->
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/sport-event/detail/2/33255043" routerlinkactive="active-menu"> Lucas Pouille v Jan Choinski </a></li><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li><!---->
                                                            </ul>
                                                        </div>
                                                    </div><!---->
                                                </li>
                                                <li _ngcontent-wey-c73=""><!----></li>
                                                <li _ngcontent-wey-c73=""><!----></li>
                                                <li _ngcontent-wey-c73="">
                                                    <div _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu5">Exchange Game <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a>
                                                        <div _ngcontent-wey-c73="" class="collapse" id="SubMenu5">
                                                            <ul _ngcontent-wey-c73="">
                                                                <li _ngcontent-wey-c73=""><!----><!----><a _ngcontent-wey-c73="" data-toggle="collapse" role="button" aria-expanded="true" href="https://crickekbuz.art/#SubMenu50">Live
                                                                        Games <b _ngcontent-wey-c73="" class="iconsmenu"><i _ngcontent-wey-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                                                    <div _ngcontent-wey-c73="" class="collapse" id="SubMenu50">
                                                                        <ul _ngcontent-wey-c73=""><!----><!----></ul>
                                                                        <ul _ngcontent-wey-c73=""><!----><!----></ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67580" routerlinkactive="active-menu" class="active-menu"> Casino War </a></li>
                                                                            <!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/90100" routerlinkactive="active-menu"> Race 20-20 </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67610" routerlinkactive="active-menu"> Trio </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67680" routerlinkactive="active-menu"> The Trap </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67570" routerlinkactive="active-menu"> Bollywood Casino </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67620" routerlinkactive="active-menu"> Queen </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67630" routerlinkactive="active-menu"> Teenpatti Test </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/92038" routerlinkactive="active-menu"> Baccarat </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67567" routerlinkactive="active-menu"> Poker 2020 </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67600" routerlinkactive="active-menu"> Mulfis Teenpatti </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67660" routerlinkactive="active-menu"> 2 Cards Teenpatti </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67575" routerlinkactive="active-menu"> Casino Meter </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98566" routerlinkactive="active-menu"> Sicbo </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/56767" routerlinkactive="active-menu"> 1 Day Teenpatti </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67564" routerlinkactive="active-menu"> 1 Day Poker </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98788" routerlinkactive="active-menu"> Roulette </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98790" routerlinkactive="active-menu"> 1 Day Dragon Tiger </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98791" routerlinkactive="active-menu"> Amar Akbar Anthony </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/87564" routerlinkactive="active-menu"> Andar Bahar </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98789" routerlinkactive="active-menu"> 7 Up &amp; Down </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/92037" routerlinkactive="active-menu"> Worli Matka </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!----><!----></ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/56768" routerlinkactive="active-menu"> Teenpatti T20 </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/56967" routerlinkactive="active-menu"> 32 Card Casino </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/56968" routerlinkactive="active-menu"> Hi-Low </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/56766" routerlinkactive="active-menu"> Teenpatti One-Day (Virtual) </a></li>
                                                                            <!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/56769" routerlinkactive="active-menu"> Teenpatti T20 (Virtual) </a></li>
                                                                            <!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98793" routerlinkactive="active-menu"> 7 up &amp; down (Virtual) </a></li>
                                                                            <!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/56966" routerlinkactive="active-menu"> 32 Cards (Virtual) </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73=""><!----><!----></ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67563" routerlinkactive="active-menu"> Poker (Virtual) </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/67566" routerlinkactive="active-menu"> Six player poker (Virtual) </a></li>
                                                                            <!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/87565" routerlinkactive="active-menu"> Andar Bahar (Virtual) </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/92036" routerlinkactive="active-menu"> Matka (Virtual) </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98792" routerlinkactive="active-menu"> Roulette (Virtual) </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98794" routerlinkactive="active-menu"> Dragon Tiger (Virtual) </a></li><!----><!---->
                                                                        </ul>
                                                                        <ul _ngcontent-wey-c73="">
                                                                            <li _ngcontent-wey-c73=""><a _ngcontent-wey-c73="" href="https://crickekbuz.art/exchange-game/1444001/98795" routerlinkactive="active-menu"> Amar Akbar Anthony (Virtual) </a></li>
                                                                            <!----><!---->
                                                                        </ul><!---->
                                                                    </div>
                                                                </li><!---->
                                                            </ul>
                                                        </div>
                                                    </div><!---->
                                                </li>
                                                <li _ngcontent-wey-c73=""><!----></li><!---->
                                            </ul>
                                        </div>
                                    </li><!---->
                                </ul>
                            </nav><!---->
                        </app-sidebar></div>
                    <div _ngcontent-wey-c75="" class="w-100 d-flex flex-nowrap overflow-auto gap-2 pt-1 pb-1 top-nav-event d-md-none"><span _ngcontent-wey-c75="" class="text-nowrap d-flex flex-nowrap gap-2 justify-content-between align-items-center text-white bg-dark p-2 rounded"><!----><!----><!----><svg _ngcontent-wey-c75="" fill="white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1022 1013" class="icon-blink" style="height: 14px;">
                                <path _ngcontent-wey-c75="" d="M335 330q-26 26-60.5 40T203 384q-21 0-41-4.5T124 366l247-242q25 52 15 109t-51 97zm19-235L94 349q-12-8-22.5-18.5T52 308L312 54q6 4 11.5 8.5T335 73q5 5 10 10.5t9 11.5zm-72-59L35 279q-21-43-18-89.5T46 104q25-40 67-62.5T203 19q20 0 40.5 4.5T282 36zm91 660l67 64 582-580L835 0 253 580l66 64L67 895l-19-18-48 48 92 88 48-48-19-19 252-250z">
                                </path>
                            </svg><!----><span _ngcontent-wey-c75="" class="blink" style="font-size: 13px;">Sunrisers Hyderabad v
                                Lucknow Super Giants</span></span><!----><span _ngcontent-wey-c75="" class="text-nowrap d-flex flex-nowrap gap-2 justify-content-between align-items-center text-white bg-dark p-2 rounded"><!----><!----><svg _ngcontent-wey-c75="" fill="white" xmlns="http://www.w3.org/2000/svg" viewBox="-0.1 -0.1 1024.1 1024.1" class="icon-blink" style="height: 14px;">
                                <path _ngcontent-wey-c75="" d="M874 150q-39-39-83-67-44-29-92-48T601 8q-51-9-101-8l208 209q52 51 77 117 26 65 26 132.5T785 591q-26 65-77 116-52 52-117 78t-132.5 26Q391 811 326 785q-65-25-117-77L0 500q-1 50 8 101 8 50 27 98t48 92q28 44 67 83 75 75 169 113 95 37 193 37t193-37q94-38 169-113t113-169q37-95 37-193t-37-193q-38-94-113-169zM264 653q39 38 89 59t105 20q55 0 105-20.5t89-59.5q39-39 59.5-89T732 458q1-55-20-105t-59-89L401 12q-69 15-133 49.5T150 150q-54 54-88.5 118T12 401l252 252z">
                                </path>
                            </svg><!----><!----><span _ngcontent-wey-c75="" class="blink" style="font-size: 13px;">Remy Bertola v
                                Rigele Te</span></span><!----><!----></div><!----><!---->
                    <div _ngcontent-wey-c75="" class="col-md-10 pxxs-0"><router-outlet _ngcontent-wey-c75=""></router-outlet><app-casino-war _nghost-wey-c115="">
                            <div _ngcontent-wey-c115="" class="both-section">
                                <div _ngcontent-wey-c115="" class="casino-center"><app-mobile-tab-header _ngcontent-wey-c115="" _nghost-wey-c89="">
                                        <div _ngcontent-wey-c89="" id="element" class="casino-container ds-block-mobile">
                                            <div _ngcontent-wey-c89="" class="listing_screen casino-tabs-om">
                                                <tabset _ngcontent-wey-c89="" _nghost-wey-c35="" class="tab-container">
                                                    <ul _ngcontent-wey-c35="" role="tablist" class="nav nav-tabs" aria-label="Tabs">
                                                        <li _ngcontent-wey-c35="" class="active nav-item"><a _ngcontent-wey-c35="" href="javascript:void(0);" role="tab" class="nav-link active" aria-controls="" aria-selected="true" id=""><span _ngcontent-wey-c35="">GAME</span><!----><!----></a>
                                                        </li>
                                                        <li _ngcontent-wey-c35="" class="nav-item"><a _ngcontent-wey-c35="" href="javascript:void(0);" role="tab" class="nav-link" aria-controls="" aria-selected="false" id=""><span _ngcontent-wey-c35=""></span> PLACED BETS(0)
                                                                <!----><!----></a></li>
                                                        <li _ngcontent-wey-c35="" class="nav-item"><a _ngcontent-wey-c35="" href="javascript:void(0);" role="tab" class="nav-link" aria-controls="" aria-selected="false" id=""><span _ngcontent-wey-c35=""></span>
                                                                <div _ngcontent-wey-c89="" class="float-right text-right round pr-2"><a _ngcontent-wey-c89="" href="javasript:void(0)" role="button" class="ml-1">Rules</a><span _ngcontent-wey-c89="" class="d-block"> Round ID: <span _ngcontent-wey-c89="">70408996</span></span></div><!----><!---->
                                                            </a></li><!---->
                                                    </ul>
                                                    <div _ngcontent-wey-c35="" class="tab-content">
                                                        <tab _ngcontent-wey-c89="" heading="GAME" role="tabpanel" aria-labelledby="" class="tab-pane active"></tab>
                                                        <tab _ngcontent-wey-c89="" role="tabpanel" aria-labelledby="" class="tab-pane">
                                                            <!----><app-my-bets-casino _ngcontent-wey-c89="" _nghost-wey-c88="">
                                                                <div _ngcontent-wey-c88="" class="bets-section">
                                                                    <h2 _ngcontent-wey-c88="">My Bet</h2>
                                                                    <div _ngcontent-wey-c88="" class="p-1">
                                                                        <table _ngcontent-wey-c88="" class="table">
                                                                            <thead _ngcontent-wey-c88="">
                                                                                <tr _ngcontent-wey-c88="">
                                                                                    <td _ngcontent-wey-c88="">Matched Bet </td>
                                                                                    <td _ngcontent-wey-c88="">Odds</td>
                                                                                    <td _ngcontent-wey-c88="">Stake</td>
                                                                                </tr>
                                                                            </thead><!---->
                                                                            <tbody _ngcontent-wey-c88="">
                                                                                <tr _ngcontent-wey-c88="">
                                                                                    <td _ngcontent-wey-c88="" colspan="3" class="text-center"> No records Found
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody><!---->
                                                                        </table>
                                                                    </div>
                                                                </div>
                                                            </app-my-bets-casino>
                                                        </tab>
                                                        <tab _ngcontent-wey-c89="" role="tabpanel" aria-labelledby="" class="tab-pane"><!----></tab>
                                                    </div>
                                                </tabset>
                                            </div>
                                        </div>
                                        <div _ngcontent-wey-c89="" bsmodal="" tabindex="-1" role="dialog" aria-labelledby="dialog-static-name" class="modal fade">
                                            <div _ngcontent-wey-c89="" class="modal-dialog modal-lr casino-rules-modal">
                                                <div _ngcontent-wey-c89="" class="modal-content">
                                                    <div _ngcontent-wey-c89="" class="modal-header border-0">
                                                        <h4 _ngcontent-wey-c89="" id="dialog-static-name" class="modal-title pull-left">Rules</h4>
                                                        <button _ngcontent-wey-c89="" type="button" aria-label="Close" class="btn-close close pull-right"><i _ngcontent-wey-c89="" class="mdi mdi-close-thick"></i></button>
                                                    </div>
                                                    <div _ngcontent-wey-c89="" class="modal-body">
                                                        <accordion _ngcontent-wey-c89="" role="tablist" class="panel-group" style="display: block;" aria-multiselectable="false"><!----></accordion>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!---->
                                    </app-mobile-tab-header>
                                    <div _ngcontent-wey-c115="" id="element" class="casino-container">
                                        <div _ngcontent-wey-c115="" class="casino-table teenpatti2024">
                                            <div _ngcontent-wey-c115="" class="casino-video">
                                                <div _ngcontent-wey-c115="" class="casino-video-title"><span _ngcontent-wey-c115="" class="casino-name">Casino War <small _ngcontent-wey-c115=""><a _ngcontent-wey-c115="" href="javascript:void(0)">rules</a></small></span><span _ngcontent-wey-c115="" class="casino-video-rid">Round ID: 70408996 <span _ngcontent-wey-c115="" class="c-min-max-head ng-star-inserted"> | Min: 100 | Max: 50000</span><!----></span>
                                                </div>
                                                <div _ngcontent-wey-c115="" class="video-box-container">
                                                    <div _ngcontent-wey-c115="" id="video-box" class="video-box" style="height: 411.75px;">
                                                        <video id="myVideo" src="http://localhost/app/public/vedio/casino_war_1.mp4" style="height: 411.75px;"  autoplay x-webkit-airplay="allow"></video>
                                                        <!-- <iframe _ngcontent-wey-c115="" allowfullscreen="" title="liveTranslation" id="c-iframe" src="https://crickekbuz.art/public/assets/saved_resource.html" style="height: 411.75px;"></iframe> -->
                                                    </div>
                                                </div>
                                                <div _ngcontent-wey-c115="" class="casino-video-cards hide-cards">
                                                    <div _ngcontent-wey-c115="" class="casino-cards-shuffle"> || </div>
                                                    <div _ngcontent-wey-c115="" class="casino-video-cards-container">
                                                        <div _ngcontent-wey-c115=""><!---->
                                                            <div _ngcontent-wey-c115=""></div>
                                                        </div>
                                                        <div _ngcontent-wey-c115="">
                                                            <div _ngcontent-wey-c115="">
                                                                <h5 _ngcontent-wey-c115="">Dealer</h5><span _ngcontent-wey-c115=""><img _ngcontent-wey-c115="" src="https://crickekbuz.art/public/assets/1.png"></span><!---->
                                                            </div><!---->
                                                            <div _ngcontent-wey-c115=""></div>
                                                        </div><!---->
                                                    </div>
                                                </div><!---->
                                                <div _ngcontent-wey-c115="" class="casino-timer d-none-mobile">
                                                    <div _ngcontent-wey-c115="" class="base-timer"><svg _ngcontent-wey-c115="" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="base-timer__svg">
                                                            <g _ngcontent-wey-c115="" class="base-timer__circle">
                                                                <circle _ngcontent-wey-c115="" cx="50" cy="50" r="45" class="base-timer__path-elapsed">
                                                                </circle>
                                                                <path _ngcontent-wey-c115="" stroke-dasharray="225 283" d="M 50, 50 m -45, 0 a 45,45 0 1,0 90,0 a 45,45 0 1,0 -90,0" class="base-timer__path-remaining green"></path>
                                                            </g>
                                                        </svg><span _ngcontent-wey-c115="" class="base-timer__label red"><span _ngcontent-wey-c115="">0</span></span></div>
                                                </div><!---->
                                            </div>
                                            <div _ngcontent-wey-c115="" class="casino-detail">
                                                <div _ngcontent-wey-c115="" class="casino-section">
                                                    <div _ngcontent-wey-c115="" class="casinobetplace">
                                                        <div _ngcontent-wey-c115="" class="casino_odds">
                                                            <!-- <div _ngcontent-wey-c115="" class="row">
                                                                <div _ngcontent-wey-c115="" class="col-md-12 col-12">
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_title"><button _ngcontent-wey-c115=""><img _ngcontent-wey-c115="" src="https://crickekbuz.art/public/assets/1.png"></button><button _ngcontent-wey-c115=""><img _ngcontent-wey-c115="" src="https://crickekbuz.art/public/assets/1.png"></button><button _ngcontent-wey-c115=""><img _ngcontent-wey-c115="" src="https://crickekbuz.art/public/assets/1.png"></button><button _ngcontent-wey-c115=""><img _ngcontent-wey-c115="" src="https://crickekbuz.art/public/assets/1.png"></button><button _ngcontent-wey-c115=""><img _ngcontent-wey-c115="" src="https://crickekbuz.art/public/assets/1.png"></button><button _ngcontent-wey-c115=""><img _ngcontent-wey-c115="" src="https://crickekbuz.art/public/assets/1.png"></button></div>
                                                                </div>
                                                            </div> -->
                                                            <div _ngcontent-wey-c115="" class="row">
                                                                <div _ngcontent-wey-c115="" class="col-md-12 col-12">
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_title"><button _ngcontent-wey-c115="" class="back">1</button><button _ngcontent-wey-c115="" class="back">2</button><button _ngcontent-wey-c115="" class="back">3</button><button _ngcontent-wey-c115="" class="back">4</button><button _ngcontent-wey-c115="" class="back">5</button><button _ngcontent-wey-c115="" class="back">6</button><button _ngcontent-wey-c115="" class="back">7</button><!----></div>
                                                                </div>
                                                            </div>
                                                            <div _ngcontent-wey-c115="" class="row">
                                                                <div _ngcontent-wey-c115="" class="col-md-12 col-12">
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_value play_bet teenpattiTest"><button _ngcontent-wey-c115="" class="back"><span _ngcontent-wey-c115="">1.98<span _ngcontent-wey-c115="">0</span></span><!----><!----></button><!----></div>
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_value play_bet teenpattiTest"><button _ngcontent-wey-c115="" class="back"><span _ngcontent-wey-c115="">1.98<span _ngcontent-wey-c115="">0</span></span><!----><!----></button><!----></div>
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_value play_bet teenpattiTest"><button _ngcontent-wey-c115="" class="back"><span _ngcontent-wey-c115="">1.98<span _ngcontent-wey-c115="">0</span></span><!----><!----></button><!----></div>
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_value play_bet teenpattiTest"><button _ngcontent-wey-c115="" class="back"><span _ngcontent-wey-c115="">1.98<span _ngcontent-wey-c115="">0</span></span><!----><!----></button><!----></div>
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_value play_bet teenpattiTest"><button _ngcontent-wey-c115="" class="back"><span _ngcontent-wey-c115="">1.98<span _ngcontent-wey-c115="">0</span></span><!----><!----></button><!----></div>
                                                                    <div _ngcontent-wey-c115="" class="btn-group c_odds_value play_bet teenpattiTest"><button _ngcontent-wey-c115="" class="back"><span _ngcontent-wey-c115="">1.98<span _ngcontent-wey-c115="">0</span></span><!----><!----></button><!----></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div _ngcontent-wey-c115="" class="casino-lastResult">
                                                <h2 _ngcontent-wey-c115="">Last Results </h2>
                                                <div _ngcontent-wey-c115="" class="clr-sec"><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><span _ngcontent-wey-c115="" class="resultText">R</span><!----></div>
                                            </div><!---->
                                        </div>
                                    </div>
                                </div>
                                <div _ngcontent-wey-c115="" id="right-sidebar-id" class="right-sidebar casino-right-sidebar teen2sidebar"><app-bet-slip-casino _ngcontent-wey-c115="" _nghost-wey-c90="">
                                        <div _ngcontent-wey-c90="" class="bets-section" style="position: relative;">
                                            <h2 _ngcontent-wey-c90="">Place Bet</h2>
                                            <div _ngcontent-wey-c90="" class="back">
                                                <div _ngcontent-wey-c90="" class="row align-items-center mx-0">
                                                    <div _ngcontent-wey-c90="" class="col"> (Bet for) </div>
                                                    <div _ngcontent-wey-c90="" class="col"> Odds </div>
                                                    <div _ngcontent-wey-c90="" class="col"> Stake </div>
                                                </div><!---->
                                                <div _ngcontent-wey-c90="" class="row align-items-center mx-0 border-top border-bottom border-light py-1">
                                                    <div _ngcontent-wey-c90="" class="col text-left"><i _ngcontent-wey-c90="" class="fa fa-close text-danger"></i> Player 2 Match Odds: Player 2 </div>
                                                    <div _ngcontent-wey-c90="" class="col"><input _ngcontent-wey-c90="" id="bet_input" type="text" readonly="true" class="form-control ng-untouched ng-pristine ng-valid"><a _ngcontent-wey-c90="" href="javascript:void(0)" class="arrow-up"><i _ngcontent-wey-c90="" class="fa fa-angle-up"></i></a><a _ngcontent-wey-c90="" href="javascript:void(0)" class="arrow-down"><i _ngcontent-wey-c90="" class="fa fa-angle-down"></i></a></div><!---->
                                                    <div _ngcontent-wey-c90="" class="col"><input _ngcontent-wey-c90="" id="add_input" type="number" placeholder="Amount" class="form-control ng-untouched ng-pristine ng-valid"></div>
                                                </div><!----><!----><!---->
                                                <div _ngcontent-wey-c90="" class="stakes">
                                                    <div _ngcontent-wey-c90="" class="btn-group"><button _ngcontent-wey-c90="" class="add_bet" type="button">100</button><button _ngcontent-wey-c90=""   class="add_bet"type="button">500</button><button _ngcontent-wey-c90=""  class="add_bet" type="button">1000</button><button _ngcontent-wey-c90=""  class="add_bet" type="button">5000</button><button _ngcontent-wey-c90=""  class="add_bet" type="button">10000</button><button _ngcontent-wey-c90=""  class="add_bet" type="button">25000</button><!----></div>
                                                </div><!---->
                                                <div _ngcontent-wey-c90="" class="row">
                                                    <div _ngcontent-wey-c90="" class="col"><button _ngcontent-wey-c90="" class="btn cancel-btn">reset</button></div>
                                                    <div _ngcontent-wey-c90="" class="col"><button _ngcontent-wey-c90="" class="btn betplace-btn bet_submit">submit</button><!----></div>
                                                </div>
                                            </div><!----><!---->
                                        </div>
                                    </app-bet-slip-casino><app-my-bets-casino _ngcontent-wey-c115="" _nghost-wey-c88="">
                                        <div _ngcontent-wey-c88="" class="bets-section">
                                            <h2 _ngcontent-wey-c88="">My Bet</h2>
                                            <div _ngcontent-wey-c88="" class="p-1">
                                                <table _ngcontent-wey-c88="" class="table">
                                                    <thead _ngcontent-wey-c88="">
                                                        <tr _ngcontent-wey-c88="">
                                                            <td _ngcontent-wey-c88="">Matched Bet </td>
                                                            <td _ngcontent-wey-c88="">Odds</td>
                                                            <td _ngcontent-wey-c88="">Stake</td>
                                                        </tr>
                                                    </thead><!---->
                                                    <tbody _ngcontent-wey-c88="">
                                                        <tr _ngcontent-wey-c88="">
                                                            <td _ngcontent-wey-c88="" colspan="3" class="text-center"> No records Found</td>
                                                        </tr>
                                                    </tbody><!---->
                                                </table>
                                            </div>
                                        </div>
                                    </app-my-bets-casino></div>
                            </div><!---->
                            <div _ngcontent-wey-c115="" bsmodal="" tabindex="-1" role="dialog" aria-labelledby="dialog-child-name" class="modal fade">
                                <div _ngcontent-wey-c115="" class="modal-dialog modal-sm inner-modal">
                                    <div _ngcontent-wey-c115="" class="modal-content">
                                        <div _ngcontent-wey-c115="" class="modal-header py-1 mobileBetplaceHeader">
                                            <h4 _ngcontent-wey-c115="" id="dialog-child-name" class="modal-title pull-left">place bet</h4>
                                            <button _ngcontent-wey-c115="" type="button" aria-label="Close" class="close pull-right"><span _ngcontent-wey-c115="" aria-hidden="true">×</span></button>
                                        </div>
                                        <div _ngcontent-wey-c115="" class="modal-body p-0"><app-bet-slip-casino _ngcontent-wey-c115="" _nghost-wey-c90="">
                                                <div _ngcontent-wey-c90="" class="bets-section" style="position: relative;">
                                                    <h2 _ngcontent-wey-c90="">Place Bet</h2>
                                                    <div _ngcontent-wey-c90="" class="back">
                                                        <div _ngcontent-wey-c90="" class="row align-items-center mx-0">
                                                            <div _ngcontent-wey-c90="" class="col"> (Bet for) </div>
                                                            <div _ngcontent-wey-c90="" class="col"> Odds </div>
                                                            <div _ngcontent-wey-c90="" class="col"> Stake </div>
                                                        </div><!---->
                                                        <div _ngcontent-wey-c90="" class="row align-items-center mx-0 border-top border-bottom border-light py-1">
                                                            <div _ngcontent-wey-c90="" class="col text-left"><i _ngcontent-wey-c90="" class="fa fa-close text-danger"></i> Player 2 Match Odds: Player 2 </div>
                                                            <div _ngcontent-wey-c90="" class="col"><input _ngcontent-wey-c90="" type="text" readonly="true" class="form-control ng-untouched ng-pristine ng-valid"><a _ngcontent-wey-c90="" href="javascript:void(0)" class="arrow-up"><i _ngcontent-wey-c90="" class="fa fa-angle-up"></i></a><a _ngcontent-wey-c90="" href="javascript:void(0)" class="arrow-down"><i _ngcontent-wey-c90="" class="fa fa-angle-down"></i></a></div><!---->
                                                            <div _ngcontent-wey-c90="" class="col"><input _ngcontent-wey-c90="" type="number" placeholder="Amount" class="form-control ng-untouched ng-pristine ng-valid"></div>
                                                        </div><!----><!----><!---->
                                                        <div _ngcontent-wey-c90="" class="stakes">
                                                            <div _ngcontent-wey-c90="" class="btn-group"><button _ngcontent-wey-c90="" type="button">100</button><button _ngcontent-wey-c90="" type="button">500</button><button _ngcontent-wey-c90="" type="button">1000</button><button _ngcontent-wey-c90="" type="button">5000</button><button _ngcontent-wey-c90="" type="button">10000</button><button _ngcontent-wey-c90="" type="button">25000</button><!----></div>
                                                        </div><!---->
                                                        <div _ngcontent-wey-c90="" class="row">
                                                            <div _ngcontent-wey-c90="" class="col"><button _ngcontent-wey-c90="" class="btn cancel-btn">reset</button></div>
                                                            <div _ngcontent-wey-c90="" class="col"><button _ngcontent-wey-c90="" class="btn betplace-btn">submit</button><!----></div>
                                                        </div>
                                                    </div><!----><!---->
                                                </div>
                                            </app-bet-slip-casino></div>
                                    </div>
                                </div>
                            </div><!---->
                        </app-casino-war><!----></div>
                </div>
            </main><app-footer _ngcontent-wey-c75="" _nghost-wey-c74="">
                <footer _ngcontent-wey-c74="" id="footer">
                    <p _ngcontent-wey-c74="" class="copyrgt text-center"> Please Gamble Responsible । <a _ngcontent-wey-c74="" target="_blank" href="https://crickekbuz.art/#/terms">Terms &amp; Conditions</a> । <a _ngcontent-wey-c74="" target="_blank" href="https://crickekbuz.art/#/license">License</a> । <a _ngcontent-wey-c74="" target="_blank" href="https://crickekbuz.art/#/privacy">Privacy Policy</a> । <a _ngcontent-wey-c74="" data-toggle="modal" data-target="#rulesModal">Rules &amp; Regulations</a> ©
                        Copyright 2020. All Rights Reserved. </p>
                </footer>
            </app-footer>
        </app-layout><!----></app-root>
    <!-- <script src="https://crickekbuz.art/public/assets/runtime.631b85bcd56c965b9ad4.js.download" defer=""></script>
  <script src="https://crickekbuz.art/public/assets/polyfills.f5b398c20c6ecfb2ab8c.js.download" defer=""></script>
  <script src="https://crickekbuz.art/public/assets/scripts.3b976f127508e59a2eee.js.download" defer=""></script>
  <script src="https://crickekbuz.art/public/assets/main.61b73650db0cfd70fc9d.js.download" defer=""></script> -->

    <div class="overlay-container" aria-live="polite">
        <div id="toast-container" class="toast-top-center toast-container"></div>
    </div>
    <script>
        $(".play_bet").click(function() {
            $("#bet_input").val("1.98");
        });
    </script>
    <script>
        $(".add_bet").click(function() {
            $("#add_input").val($(this).text());
        });
    </script>
    <script>
        $(".bet_submit").click(function() {
           alert("Market is currently not OPEN. Please try again after some time.");
        });
    </script>
</body>

</html>