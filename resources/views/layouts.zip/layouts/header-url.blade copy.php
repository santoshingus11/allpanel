  <title>Lordsexch | Super Master | Lordsexch | Home</title>
  <!-- End fonts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- core:css -->
  <link rel="stylesheet" href="{{asset('admin/assets/css/core.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/flatpickr.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/fonts/feather-font/css/iconfont.css">
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/flag-icon.min.css">
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/style.min.css">
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/user.css">
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/main.css">
  <style>
     .flash__message {
        padding: 12px;
        background-color: aliceblue;
        border-radius: 4px;
    }
    .flash__message.error {
color: #fff;
background-color: #a94442;
border-color: #a94442;
text-align: center;
font-size: larger;
display: none;
}
  </style>
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/select2.min.css">
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/responsive.css">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/daterangepicker.css">
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/admin.css">
  <link rel="stylesheet" href="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/dropify.min.css">
  <script type="text/javascript" src="https://clone-lordsexch.mrmmbs.com/Master-Admin/assets/css/daterangepicker.js"></script>
  <!-- End layout styles -->
  <link rel="shortcut icon" href="{{asset('admin/Super-Admin/assets/img/favicon.png')}}" />
  