<app-sidebar _ngcontent-vsf-c75="" _nghost-vsf-c73=""
                ><nav _ngcontent-vsf-c73="" class="nav-menu">
                  <ul _ngcontent-vsf-c73="">
                    <li _ngcontent-vsf-c73="">
                      <a
                        _ngcontent-vsf-c73=""
                        data-toggle="collapse"
                        data-savepage-href="#SubsideMenu1"
                        href="https://cricket247buzz.com/#SubsideMenu1"
                        role="button"
                        aria-expanded="true"
                        aria-controls="SubsideMenu1"
                        class="active"
                        ><span _ngcontent-vsf-c73="">Casino</span
                        ><b _ngcontent-vsf-c73="" class="iconsmenu"
                          ><i
                            _ngcontent-vsf-c73=""
                            class="fa fa-chevron-down"
                          ></i></b
                      ></a>
                      <div
                        _ngcontent-vsf-c73=""
                        id="SubsideMenu1"
                        class="collapse show"
                      >
                        <ul _ngcontent-vsf-c73="">
                          <!----><!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!----><!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Casino War
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Race 20-20
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73=""> Trio </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73=""> The Trap </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Bollywood Casino
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73=""> Queen </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Teenpatti Test
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73=""> Baccarat </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Poker 2020
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Mulfis Teenpatti
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                2 Cards Teenpatti
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Casino Meter
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73=""> Sicbo </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                1 Day Teenpatti
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                1 Day Poker
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73=""> Roulette </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                1 Day Dragon Tiger
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Amar Akbar Anthony
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Andar Bahar
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                7 Up &amp; Down
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Worli Matka
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Teenpatti T20
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                32 Card Casino
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73=""> Hi-Low </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Teenpatti One-Day (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Teenpatti T20 (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                7 up &amp; down (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                32 Cards (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Poker (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Six player poker (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Andar Bahar (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Matka (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Roulette (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Dragon Tiger (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <ul _ngcontent-vsf-c73="">
                          <!---->
                          <li _ngcontent-vsf-c73="">
                            <a _ngcontent-vsf-c73=""
                              ><span _ngcontent-vsf-c73="">
                                Amar Akbar Anthony (Virtual)
                              </span></a
                            >
                          </li>
                          <!---->
                        </ul>
                        <!---->
                      </div>
                    </li>
                    <!---->
                    <li _ngcontent-vsf-c73="">
                      <a
                        _ngcontent-vsf-c73=""
                        data-toggle="collapse"
                        data-savepage-href="#SubsideMenu2"
                        href="https://cricket247buzz.com/#SubsideMenu2"
                        role="button"
                        aria-expanded="true"
                        aria-controls="SubsideMenu1"
                        class="active"
                        ><span _ngcontent-vsf-c73="">Sports</span
                        ><b _ngcontent-vsf-c73="" class="iconsmenu"
                          ><i
                            _ngcontent-vsf-c73=""
                            class="fa fa-chevron-down"
                          ></i></b
                      ></a>
                      <div
                        _ngcontent-vsf-c73=""
                        id="SubsideMenu2"
                        class="collapse show"
                      >
                        <ul _ngcontent-vsf-c73="">
                          <li _ngcontent-vsf-c73="">
                            <div _ngcontent-vsf-c73="">
                              <a
                                _ngcontent-vsf-c73=""
                                data-toggle="collapse"
                                role="button"
                                aria-expanded="true"
                                data-savepage-href="#SubMenu0"
                                href="https://cricket247buzz.com/#SubMenu0"
                                >Cricket
                                <b _ngcontent-vsf-c73="" class="iconsmenu"
                                  ><i
                                    _ngcontent-vsf-c73=""
                                    class="fa fa-chevron-down"
                                  ></i></b
                              ></a>
                              <div
                                _ngcontent-vsf-c73=""
                                class="collapse"
                                id="SubMenu0"
                              >
                                <ul _ngcontent-vsf-c73="">
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu00"
                                      href="https://cricket247buzz.com/#SubMenu00"
                                      >Indian Premier League
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu00"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/28127348"
                                            href="https://cricket247buzz.com/sport-event/detail/4/28127348"
                                            routerlinkactive="active-menu"
                                          >
                                            Indian Premier League
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33229442"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33229442"
                                            routerlinkactive="active-menu"
                                          >
                                            Royal Challengers Bengaluru v
                                            Gujarat Titans
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33229455"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33229455"
                                            routerlinkactive="active-menu"
                                          >
                                            Punjab Kings v Chennai Super Kings
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33229458"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33229458"
                                            routerlinkactive="active-menu"
                                          >
                                            Lucknow Super Giants v Kolkata
                                            Knight Riders
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33229422"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33229422"
                                            routerlinkactive="active-menu"
                                          >
                                            Mumbai Indians v Kolkata Knight
                                            Riders
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33239077"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33239077"
                                            routerlinkactive="active-menu"
                                          >
                                            Mumbai Indians v Sunrisers Hyderabad
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33238951"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33238951"
                                            routerlinkactive="active-menu"
                                          >
                                            Delhi Capitals v Rajasthan Royals
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu01"
                                      href="https://cricket247buzz.com/#SubMenu01"
                                      >Election
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu01"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/240113031023"
                                            href="https://cricket247buzz.com/sport-event/detail/4/240113031023"
                                            routerlinkactive="active-menu"
                                          >
                                            BJP LS v CON LS
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu02"
                                      href="https://cricket247buzz.com/#SubMenu02"
                                      >T20 International SRL
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu02"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708945"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708945"
                                            routerlinkactive="active-menu"
                                          >
                                            England SRL vs. Australia SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708949"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708949"
                                            routerlinkactive="active-menu"
                                          >
                                            South Africa SRL vs. India SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708951"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708951"
                                            routerlinkactive="active-menu"
                                          >
                                            Sri Lanka Srl vs. New Zealand SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708953"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708953"
                                            routerlinkactive="active-menu"
                                          >
                                            West Indies Srl vs. Pakistan SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708955"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708955"
                                            routerlinkactive="active-menu"
                                          >
                                            Bangladesh Srl vs. Afghanistan Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708957"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708957"
                                            routerlinkactive="active-menu"
                                          >
                                            Australia SRL vs. New Zealand SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu03"
                                      href="https://cricket247buzz.com/#SubMenu03"
                                      >List-A Series Sri Lanka A vs Afghanistan
                                      A
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu03"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49172493"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49172493"
                                            routerlinkactive="active-menu"
                                          >
                                            Sri Lanka A vs. Afghanistan A
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu04"
                                      href="https://cricket247buzz.com/#SubMenu04"
                                      >Womens International Twenty20 Matches
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu04"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33242214"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33242214"
                                            routerlinkactive="active-menu"
                                          >
                                            Pakistan Women v West Indies Women
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33242108"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33242108"
                                            routerlinkactive="active-menu"
                                          >
                                            Bangladesh Women v India Women
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu05"
                                      href="https://cricket247buzz.com/#SubMenu05"
                                      >International Twenty20 Matches
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu05"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/33242084"
                                            href="https://cricket247buzz.com/sport-event/detail/4/33242084"
                                            routerlinkactive="active-menu"
                                          >
                                            Bangladesh v Zimbabwe
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu06"
                                      href="https://cricket247buzz.com/#SubMenu06"
                                      >Big Bash League SRL
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu06"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708225"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708225"
                                            routerlinkactive="active-menu"
                                          >
                                            Sydney Sixers SRL vs. Brisbane Heat
                                            Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708227"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708227"
                                            routerlinkactive="active-menu"
                                          >
                                            Sydney Thunder Srl vs. Hobart
                                            Hurricanes Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708229"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708229"
                                            routerlinkactive="active-menu"
                                          >
                                            Melbourne Stars SRL vs. Melbourne
                                            Renegades Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu07"
                                      href="https://cricket247buzz.com/#SubMenu07"
                                      >ICC Women's T20 World Cup Qualifier
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu07"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49011915"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49011915"
                                            routerlinkactive="active-menu"
                                          >
                                            United Arab Emirates vs. Vanuatu
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49011865"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49011865"
                                            routerlinkactive="active-menu"
                                          >
                                            Scotland vs. Thailand
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49011917"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49011917"
                                            routerlinkactive="active-menu"
                                          >
                                            Ireland vs. Netherlands
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu08"
                                      href="https://cricket247buzz.com/#SubMenu08"
                                      >Pakistan Super League SRL
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu08"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708533"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708533"
                                            routerlinkactive="active-menu"
                                          >
                                            Quetta Gladiators Srl vs. Lahore
                                            Qalanders Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708535"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708535"
                                            routerlinkactive="active-menu"
                                          >
                                            Karachi Kings Srl vs. Peshawar Zalmi
                                            SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708537"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708537"
                                            routerlinkactive="active-menu"
                                          >
                                            Islamabad United Srl vs. Quetta
                                            Gladiators Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708539"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708539"
                                            routerlinkactive="active-menu"
                                          >
                                            Peshawar Zalmi SRL vs. Lahore
                                            Qalanders Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu09"
                                      href="https://cricket247buzz.com/#SubMenu09"
                                      >SA T20 League SRL
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu09"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708659"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708659"
                                            routerlinkactive="active-menu"
                                          >
                                            Joburg Super Kings Srl vs. Pretoria
                                            Capitals Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708661"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708661"
                                            routerlinkactive="active-menu"
                                          >
                                            Durban Super Giants Srl vs.
                                            Sunrisers Eastern Cape Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708663"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708663"
                                            routerlinkactive="active-menu"
                                          >
                                            Pretoria Capitals Srl vs. Mi Cape
                                            Town Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu010"
                                      href="https://cricket247buzz.com/#SubMenu010"
                                      >Inter Provincial Trophy
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu010"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49534383"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49534383"
                                            routerlinkactive="active-menu"
                                          >
                                            Leinster Lightning vs. Northern
                                            Knights
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu011"
                                      href="https://cricket247buzz.com/#SubMenu011"
                                      >Guyana T10 Blast
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu011"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49594627"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49594627"
                                            routerlinkactive="active-menu"
                                          >
                                            Essequibo Jaguars vs. Berbice
                                            Caimans
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49594631"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49594631"
                                            routerlinkactive="active-menu"
                                          >
                                            Demerara Pitbulls vs. Essequibo
                                            Anacondas
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu012"
                                      href="https://cricket247buzz.com/#SubMenu012"
                                      >Caribbean Premier League SRL
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu012"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708355"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708355"
                                            routerlinkactive="active-menu"
                                          >
                                            Guyana Amazon Warriors Srl vs. St
                                            Kitts And Nevis Patriots Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708357"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708357"
                                            routerlinkactive="active-menu"
                                          >
                                            Jamaica Tallawahs SRL vs. Barbados
                                            Royals Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708359"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708359"
                                            routerlinkactive="active-menu"
                                          >
                                            St Kitts And Nevis Patriots Srl vs.
                                            St Lucia Kings Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49708361"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49708361"
                                            routerlinkactive="active-menu"
                                          >
                                            Trinbago Knight Riders SRL vs.
                                            Guyana Amazon Warriors Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu013"
                                      href="https://cricket247buzz.com/#SubMenu013"
                                      >T20 Series Nepal vs. West Indies A
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu013"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/4/49404225"
                                            href="https://cricket247buzz.com/sport-event/detail/4/49404225"
                                            routerlinkactive="active-menu"
                                          >
                                            Nepal vs. West Indies A
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <!---->
                                </ul>
                              </div>
                            </div>
                            <!---->
                          </li>
                          <li _ngcontent-vsf-c73="">
                            <div _ngcontent-vsf-c73="">
                              <a
                                _ngcontent-vsf-c73=""
                                data-toggle="collapse"
                                role="button"
                                aria-expanded="true"
                                data-savepage-href="#SubMenu1"
                                href="https://cricket247buzz.com/#SubMenu1"
                                >Football
                                <b _ngcontent-vsf-c73="" class="iconsmenu"
                                  ><i
                                    _ngcontent-vsf-c73=""
                                    class="fa fa-chevron-down"
                                  ></i></b
                              ></a>
                              <div
                                _ngcontent-vsf-c73=""
                                class="collapse"
                                id="SubMenu1"
                              >
                                <ul _ngcontent-vsf-c73="">
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu10"
                                      href="https://cricket247buzz.com/#SubMenu10"
                                      >J.League
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu10"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/47273177"
                                            href="https://cricket247buzz.com/sport-event/detail/1/47273177"
                                            routerlinkactive="active-menu"
                                          >
                                            Albirex Niigata vs. Sanfrecce
                                            Hiroshima
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu11"
                                      href="https://cricket247buzz.com/#SubMenu11"
                                      >Ligue 1 SRL
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu11"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/49782449"
                                            href="https://cricket247buzz.com/sport-event/detail/1/49782449"
                                            routerlinkactive="active-menu"
                                          >
                                            Toulouse FC SRL vs. Montpellier HSC
                                            SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/49782609"
                                            href="https://cricket247buzz.com/sport-event/detail/1/49782609"
                                            routerlinkactive="active-menu"
                                          >
                                            RC Lens Srl vs. FC Lorient Srl
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu12"
                                      href="https://cricket247buzz.com/#SubMenu12"
                                      >Youth League
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu12"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/47576509"
                                            href="https://cricket247buzz.com/sport-event/detail/1/47576509"
                                            routerlinkactive="active-menu"
                                          >
                                            FK Zenit St. Petersburg vs. FC
                                            Orenburg Youth
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/47576361"
                                            href="https://cricket247buzz.com/sport-event/detail/1/47576361"
                                            routerlinkactive="active-menu"
                                          >
                                            Samara Kryliya Sovetov vs. Strogino
                                            Moscow
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu13"
                                      href="https://cricket247buzz.com/#SubMenu13"
                                      >Japanese J League
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu13"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33240151"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33240151"
                                            routerlinkactive="active-menu"
                                          >
                                            Nagoya v Kobe
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu14"
                                      href="https://cricket247buzz.com/#SubMenu14"
                                      >Bundesliga SRL
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu14"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/49782293"
                                            href="https://cricket247buzz.com/sport-event/detail/1/49782293"
                                            routerlinkactive="active-menu"
                                          >
                                            TSG 1899 Hoffenheim SRL vs. RB
                                            Leipzig SRL
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu15"
                                      href="https://cricket247buzz.com/#SubMenu15"
                                      >German Bundesliga 2
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu15"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228759"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228759"
                                            routerlinkactive="active-menu"
                                          >
                                            Hamburger SV v St Pauli
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33231137"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33231137"
                                            routerlinkactive="active-menu"
                                          >
                                            Fortuna Dusseldorf v Nurnberg
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu16"
                                      href="https://cricket247buzz.com/#SubMenu16"
                                      >Danish Superliga
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu16"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232300"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232300"
                                            routerlinkactive="active-menu"
                                          >
                                            AGF v FC Nordsjaelland
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu17"
                                      href="https://cricket247buzz.com/#SubMenu17"
                                      >Turkish Super League
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu17"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33231644"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33231644"
                                            routerlinkactive="active-menu"
                                          >
                                            Besiktas v Rizespor
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33231642"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33231642"
                                            routerlinkactive="active-menu"
                                          >
                                            Ankaragucu v Alanyaspor
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu18"
                                      href="https://cricket247buzz.com/#SubMenu18"
                                      >French Ligue 1
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu18"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223300"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223300"
                                            routerlinkactive="active-menu"
                                          >
                                            Toulouse v Montpellier
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223303"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223303"
                                            routerlinkactive="active-menu"
                                          >
                                            Lens v Lorient
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223298"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223298"
                                            routerlinkactive="active-menu"
                                          >
                                            Le Havre v Strasbourg
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223273"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223273"
                                            routerlinkactive="active-menu"
                                          >
                                            Monaco v Clermont
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223305"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223305"
                                            routerlinkactive="active-menu"
                                          >
                                            Metz v Rennes
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223260"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223260"
                                            routerlinkactive="active-menu"
                                          >
                                            Brest v Nantes
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223664"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223664"
                                            routerlinkactive="active-menu"
                                          >
                                            Lille v Lyon
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232192"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232192"
                                            routerlinkactive="active-menu"
                                          >
                                            Nice v Le Havre
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232355"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232355"
                                            routerlinkactive="active-menu"
                                          >
                                            Paris St-G v Toulouse
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu19"
                                      href="https://cricket247buzz.com/#SubMenu19"
                                      >Dutch Eredivisie
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu19"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33227105"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33227105"
                                            routerlinkactive="active-menu"
                                          >
                                            Almere City v Heerenveen
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33231525"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33231525"
                                            routerlinkactive="active-menu"
                                          >
                                            Fortuna Sittard v Go Ahead Eagles
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu110"
                                      href="https://cricket247buzz.com/#SubMenu110"
                                      >German Bundesliga
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu110"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212040"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212040"
                                            routerlinkactive="active-menu"
                                          >
                                            Hoffenheim v RB Leipzig
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212041"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212041"
                                            routerlinkactive="active-menu"
                                          >
                                            Dortmund v Augsburg
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212027"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212027"
                                            routerlinkactive="active-menu"
                                          >
                                            Stuttgart v Bayern Munich
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212042"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212042"
                                            routerlinkactive="active-menu"
                                          >
                                            Wolfsburg v SV Darmstadt
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212086"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212086"
                                            routerlinkactive="active-menu"
                                          >
                                            Werder Bremen v Mgladbach
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212052"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212052"
                                            routerlinkactive="active-menu"
                                          >
                                            FC Koln v Freiburg
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212038"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212038"
                                            routerlinkactive="active-menu"
                                          >
                                            Union Berlin v Bochum
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212037"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212037"
                                            routerlinkactive="active-menu"
                                          >
                                            Eintracht Frankfurt v Leverkusen
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212087"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212087"
                                            routerlinkactive="active-menu"
                                          >
                                            FC Heidenheim v Mainz
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu111"
                                      href="https://cricket247buzz.com/#SubMenu111"
                                      >Spanish Segunda Division
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu111"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33231311"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33231311"
                                            routerlinkactive="active-menu"
                                          >
                                            Villarreal B v Levante
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu112"
                                      href="https://cricket247buzz.com/#SubMenu112"
                                      >Italian Serie A
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu112"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212078"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212078"
                                            routerlinkactive="active-menu"
                                          >
                                            Torino v Bologna
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212104"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212104"
                                            routerlinkactive="active-menu"
                                          >
                                            AC Monza v Lazio
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212103"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212103"
                                            routerlinkactive="active-menu"
                                          >
                                            Sassuolo v Inter
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212077"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212077"
                                            routerlinkactive="active-menu"
                                          >
                                            Cagliari v Lecce
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212064"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212064"
                                            routerlinkactive="active-menu"
                                          >
                                            Empoli v Frosinone
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212107"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212107"
                                            routerlinkactive="active-menu"
                                          >
                                            Verona v Fiorentina
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212082"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212082"
                                            routerlinkactive="active-menu"
                                          >
                                            AC Milan v Genoa
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212098"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212098"
                                            routerlinkactive="active-menu"
                                          >
                                            Roma v Juventus
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212108"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212108"
                                            routerlinkactive="active-menu"
                                          >
                                            Salernitana v Atalanta
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33212099"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33212099"
                                            routerlinkactive="active-menu"
                                          >
                                            Udinese v Napoli
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33243059"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33243059"
                                            routerlinkactive="active-menu"
                                          >
                                            Frosinone v Inter
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33242387"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33242387"
                                            routerlinkactive="active-menu"
                                          >
                                            AC Milan v Cagliari
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu113"
                                      href="https://cricket247buzz.com/#SubMenu113"
                                      >English Premier League
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu113"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223295"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223295"
                                            routerlinkactive="active-menu"
                                          >
                                            Luton v Everton
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223293"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223293"
                                            routerlinkactive="active-menu"
                                          >
                                            Arsenal v Bournemouth
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223249"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223249"
                                            routerlinkactive="active-menu"
                                          >
                                            Burnley v Newcastle
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223252"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223252"
                                            routerlinkactive="active-menu"
                                          >
                                            Brentford v Fulham
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223255"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223255"
                                            routerlinkactive="active-menu"
                                          >
                                            Sheff Utd v Nottm Forest
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223296"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223296"
                                            routerlinkactive="active-menu"
                                          >
                                            Man City v Wolves
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223288"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223288"
                                            routerlinkactive="active-menu"
                                          >
                                            Brighton v Aston Villa
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223269"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223269"
                                            routerlinkactive="active-menu"
                                          >
                                            Chelsea v West Ham
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33223284"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33223284"
                                            routerlinkactive="active-menu"
                                          >
                                            Liverpool v Tottenham
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232254"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232254"
                                            routerlinkactive="active-menu"
                                          >
                                            West Ham v Luton
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232222"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232222"
                                            routerlinkactive="active-menu"
                                          >
                                            Newcastle v Brighton
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu114"
                                      href="https://cricket247buzz.com/#SubMenu114"
                                      >Spanish La Liga
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu114"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213580"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213580"
                                            routerlinkactive="active-menu"
                                          >
                                            Getafe v Athletic Bilbao
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213589"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213589"
                                            routerlinkactive="active-menu"
                                          >
                                            Real Sociedad v Las Palmas
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213578"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213578"
                                            routerlinkactive="active-menu"
                                          >
                                            Real Madrid v Cadiz
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213582"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213582"
                                            routerlinkactive="active-menu"
                                          >
                                            Girona v Barcelona
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213585"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213585"
                                            routerlinkactive="active-menu"
                                          >
                                            Mallorca v Atletico Madrid
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213571"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213571"
                                            routerlinkactive="active-menu"
                                          >
                                            Osasuna v Betis
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213576"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213576"
                                            routerlinkactive="active-menu"
                                          >
                                            Celta Vigo v Villarreal
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213609"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213609"
                                            routerlinkactive="active-menu"
                                          >
                                            Sevilla v Granada
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33213588"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33213588"
                                            routerlinkactive="active-menu"
                                          >
                                            Rayo Vallecano v Almeria
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232281"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232281"
                                            routerlinkactive="active-menu"
                                          >
                                            Valencia v Rayo Vallecano
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu115"
                                      href="https://cricket247buzz.com/#SubMenu115"
                                      >Portuguese Primeira Liga
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu115"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33231482"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33231482"
                                            routerlinkactive="active-menu"
                                          >
                                            Moreirense v Vizela
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu116"
                                      href="https://cricket247buzz.com/#SubMenu116"
                                      >Australian A-League Men
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu116"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232568"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232568"
                                            routerlinkactive="active-menu"
                                          >
                                            Sydney FC v Macarthur FC
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33232571"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33232571"
                                            routerlinkactive="active-menu"
                                          >
                                            Melbourne Victory v Melbourne City
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu117"
                                      href="https://cricket247buzz.com/#SubMenu117"
                                      >English Championship
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu117"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228822"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228822"
                                            routerlinkactive="active-menu"
                                          >
                                            Swansea v Millwall
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228839"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228839"
                                            routerlinkactive="active-menu"
                                          >
                                            Ipswich v Huddersfield
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228818"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228818"
                                            routerlinkactive="active-menu"
                                          >
                                            Birmingham v Norwich
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228829"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228829"
                                            routerlinkactive="active-menu"
                                          >
                                            Leeds v Southampton
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228806"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228806"
                                            routerlinkactive="active-menu"
                                          >
                                            Rotherham v Cardiff
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228821"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228821"
                                            routerlinkactive="active-menu"
                                          >
                                            Leicester v Blackburn
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228826"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228826"
                                            routerlinkactive="active-menu"
                                          >
                                            West Brom v Preston
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228823"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228823"
                                            routerlinkactive="active-menu"
                                          >
                                            Middlesbrough v Watford
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228814"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228814"
                                            routerlinkactive="active-menu"
                                          >
                                            Sunderland v Sheff Wed
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33228824"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33228824"
                                            routerlinkactive="active-menu"
                                          >
                                            Stoke v Bristol City
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu118"
                                      href="https://cricket247buzz.com/#SubMenu118"
                                      >English League 1
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu118"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33229245"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33229245"
                                            routerlinkactive="active-menu"
                                          >
                                            Oxford Utd v Peterborough
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu119"
                                      href="https://cricket247buzz.com/#SubMenu119"
                                      >US Major League Football
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu119"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214900"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214900"
                                            routerlinkactive="active-menu"
                                          >
                                            Inter Miami CF v New York Red Bulls
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214920"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214920"
                                            routerlinkactive="active-menu"
                                          >
                                            Charlotte FC v Portland Timbers
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214892"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214892"
                                            routerlinkactive="active-menu"
                                          >
                                            Atlanta Utd v Minnesota Utd
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214899"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214899"
                                            routerlinkactive="active-menu"
                                          >
                                            DC Utd v Philadelphia
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214898"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214898"
                                            routerlinkactive="active-menu"
                                          >
                                            Toronto FC v FC Dallas
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214894"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214894"
                                            routerlinkactive="active-menu"
                                          >
                                            San Jose Earthquakes v Los Angeles
                                            FC
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214897"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214897"
                                            routerlinkactive="active-menu"
                                          >
                                            Orlando City v FC Cincinnati
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214902"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214902"
                                            routerlinkactive="active-menu"
                                          >
                                            Houston Dynamo v St Louis City SC
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214914"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214914"
                                            routerlinkactive="active-menu"
                                          >
                                            Chicago Fire v New England
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33214922"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33214922"
                                            routerlinkactive="active-menu"
                                          >
                                            Nashville SC v CF Montreal
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu120"
                                      href="https://cricket247buzz.com/#SubMenu120"
                                      >UEFA Europa League
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu120"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33242897"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33242897"
                                            routerlinkactive="active-menu"
                                          >
                                            Atalanta v Marseille
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu121"
                                      href="https://cricket247buzz.com/#SubMenu121"
                                      >German Cup
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu121"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33164647"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33164647"
                                            routerlinkactive="active-menu"
                                          >
                                            Kaiserslautern v Leverkusen
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu122"
                                      href="https://cricket247buzz.com/#SubMenu122"
                                      >French Cup
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu122"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33165611"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33165611"
                                            routerlinkactive="active-menu"
                                          >
                                            Lyon v Paris St-G
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu123"
                                      href="https://cricket247buzz.com/#SubMenu123"
                                      >UEFA Euro 2024
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu123"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949254"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949254"
                                            routerlinkactive="active-menu"
                                          >
                                            Germany v Scotland
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949256"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949256"
                                            routerlinkactive="active-menu"
                                          >
                                            Hungary v Switzerland
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949282"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949282"
                                            routerlinkactive="active-menu"
                                          >
                                            Spain v Croatia
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949284"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949284"
                                            routerlinkactive="active-menu"
                                          >
                                            Italy v Albania
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/33143036"
                                            href="https://cricket247buzz.com/sport-event/detail/1/33143036"
                                            routerlinkactive="active-menu"
                                          >
                                            Poland v Netherlands
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949285"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949285"
                                            routerlinkactive="active-menu"
                                          >
                                            Slovenia v Denmark
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949287"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949287"
                                            routerlinkactive="active-menu"
                                          >
                                            Serbia v England
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949292"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949292"
                                            routerlinkactive="active-menu"
                                          >
                                            Belgium v Slovakia
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949297"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949297"
                                            routerlinkactive="active-menu"
                                          >
                                            Austria v France
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/32949298"
                                            href="https://cricket247buzz.com/sport-event/detail/1/32949298"
                                            routerlinkactive="active-menu"
                                          >
                                            Portugal v Czech Republic
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu124"
                                      href="https://cricket247buzz.com/#SubMenu124"
                                      >Copa America
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu124"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023231"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023231"
                                            routerlinkactive="active-menu"
                                          >
                                            Argentina vs. Canada
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023233"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023233"
                                            routerlinkactive="active-menu"
                                          >
                                            Peru vs. Chile
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023489"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023489"
                                            routerlinkactive="active-menu"
                                          >
                                            Mexico vs. Jamaica
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023491"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023491"
                                            routerlinkactive="active-menu"
                                          >
                                            Ecuador vs. Venezuela
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023625"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023625"
                                            routerlinkactive="active-menu"
                                          >
                                            Uruguay vs. Panama
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023623"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023623"
                                            routerlinkactive="active-menu"
                                          >
                                            USA vs. Bolivia
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023761"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023761"
                                            routerlinkactive="active-menu"
                                          >
                                            Colombia vs. Paraguay
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/1/46023759"
                                            href="https://cricket247buzz.com/sport-event/detail/1/46023759"
                                            routerlinkactive="active-menu"
                                          >
                                            Brazil vs. Costa Rica
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <!---->
                                </ul>
                              </div>
                            </div>
                            <!---->
                          </li>
                          <li _ngcontent-vsf-c73="">
                            <div _ngcontent-vsf-c73="">
                              <a
                                _ngcontent-vsf-c73=""
                                data-toggle="collapse"
                                role="button"
                                aria-expanded="true"
                                data-savepage-href="#SubMenu2"
                                href="https://cricket247buzz.com/#SubMenu2"
                                >Tennis
                                <b _ngcontent-vsf-c73="" class="iconsmenu"
                                  ><i
                                    _ngcontent-vsf-c73=""
                                    class="fa fa-chevron-down"
                                  ></i></b
                              ></a>
                              <div
                                _ngcontent-vsf-c73=""
                                class="collapse"
                                id="SubMenu2"
                              >
                                <ul _ngcontent-vsf-c73="">
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu20"
                                      href="https://cricket247buzz.com/#SubMenu20"
                                      >WTA Saint-Malo 2024
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu20"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33230991"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33230991"
                                            routerlinkactive="active-menu"
                                          >
                                            Burel v Els Jacquemot
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33242126"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33242126"
                                            routerlinkactive="active-menu"
                                          >
                                            Pe Stearns v Paquet
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33240300"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33240300"
                                            routerlinkactive="active-menu"
                                          >
                                            Burel v Ce Naef
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33242398"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33242398"
                                            routerlinkactive="active-menu"
                                          >
                                            A. Cornet v Jes Ponchet
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33242131"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33242131"
                                            routerlinkactive="active-menu"
                                          >
                                            Volynets v Boisson
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu21"
                                      href="https://cricket247buzz.com/#SubMenu21"
                                      >ATP Guangzhou Challenger
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu21"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33241866"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33241866"
                                            routerlinkactive="active-menu"
                                          >
                                            Yuta Shimizu v Maxime Cressy
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33239595"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33239595"
                                            routerlinkactive="active-menu"
                                          >
                                            Beibit Zhukayev v Adam Walton
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33239877"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33239877"
                                            routerlinkactive="active-menu"
                                          >
                                            Yunchaokete Bu v James Duckworth
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33241867"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33241867"
                                            routerlinkactive="active-menu"
                                          >
                                            Yu Hsiou Hsu v Tristan Schoolkate
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu22"
                                      href="https://cricket247buzz.com/#SubMenu22"
                                      >ATP Aix en Provence Challenger
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu22"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33240359"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33240359"
                                            routerlinkactive="active-menu"
                                          >
                                            Arthur Rinderknech v Tomas Martin
                                            Etcheverry
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33237264"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33237264"
                                            routerlinkactive="active-menu"
                                          >
                                            Jaume Munar v Alexandre Muller
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33240487"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33240487"
                                            routerlinkactive="active-menu"
                                          >
                                            Facundo Bagnis v Alexander
                                            Shevchenko
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33240358"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33240358"
                                            routerlinkactive="active-menu"
                                          >
                                            Valentin Vacherot v Felipe Meligeni
                                            Rodrigues Alve
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33240475"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33240475"
                                            routerlinkactive="active-menu"
                                          >
                                            Alejandro Tabilo v Hugo Gaston
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33237274"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33237274"
                                            routerlinkactive="active-menu"
                                          >
                                            Adrian Mannarino v Richard Gasquet
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu23"
                                      href="https://cricket247buzz.com/#SubMenu23"
                                      >WTA Lleida 2024
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu23"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33241947"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33241947"
                                            routerlinkactive="active-menu"
                                          >
                                            A Rus v G Maristany Zuleta De R
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33242389"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33242389"
                                            routerlinkactive="active-menu"
                                          >
                                            Emm Navarro v M Sherif
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33242244"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33242244"
                                            routerlinkactive="active-menu"
                                          >
                                            As Krueger v K Siniakova
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33241791"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33241791"
                                            routerlinkactive="active-menu"
                                          >
                                            Ca Osorio v Frech
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu24"
                                      href="https://cricket247buzz.com/#SubMenu24"
                                      >ATP Cagliari Challenger
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu24"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33242697"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33242697"
                                            routerlinkactive="active-menu"
                                          >
                                            Nuno Borges v Lorenzo Musetti
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33243448"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33243448"
                                            routerlinkactive="active-menu"
                                          >
                                            Mariano Navone v Emilio Nava
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33243204"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33243204"
                                            routerlinkactive="active-menu"
                                          >
                                            Federico Coria v Luciano Darderi
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu25"
                                      href="https://cricket247buzz.com/#SubMenu25"
                                      >ATP Porto Alegre Challenger
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu25"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33243151"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33243151"
                                            routerlinkactive="active-menu"
                                          >
                                            Karue Sell v Facundo Mena
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33243152"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33243152"
                                            routerlinkactive="active-menu"
                                          >
                                            Gonzalo Bueno v Juan Carlos Prado
                                            Angelo
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33243483"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33243483"
                                            routerlinkactive="active-menu"
                                          >
                                            Ergi Kirkin v Juan Bautista Torres
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33243154"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33243154"
                                            routerlinkactive="active-menu"
                                          >
                                            Daniel Dutra Da Silva v Guido Ivan
                                            Justo
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu26"
                                      href="https://cricket247buzz.com/#SubMenu26"
                                      >ATP Madrid Open
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu26"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33241318"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33241318"
                                            routerlinkactive="active-menu"
                                          >
                                            Taylor Fritz v Andrey Rublev
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!---->
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/sport-event/detail/2/33243278"
                                            href="https://cricket247buzz.com/sport-event/detail/2/33243278"
                                            routerlinkactive="active-menu"
                                          >
                                            Felix Auger Aliassime v Jiri Lehecka
                                          </a>
                                        </li>
                                        <!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <!---->
                                </ul>
                              </div>
                            </div>
                            <!---->
                          </li>
                          <li _ngcontent-vsf-c73=""><!----></li>
                          <li _ngcontent-vsf-c73=""><!----></li>
                          <li _ngcontent-vsf-c73="">
                            <div _ngcontent-vsf-c73="">
                              <a
                                _ngcontent-vsf-c73=""
                                data-toggle="collapse"
                                role="button"
                                aria-expanded="true"
                                data-savepage-href="#SubMenu5"
                                href="https://cricket247buzz.com/#SubMenu5"
                                >Exchange Game
                                <b _ngcontent-vsf-c73="" class="iconsmenu"
                                  ><i
                                    _ngcontent-vsf-c73=""
                                    class="fa fa-chevron-down"
                                  ></i></b
                              ></a>
                              <div
                                _ngcontent-vsf-c73=""
                                class="collapse"
                                id="SubMenu5"
                              >
                                <ul _ngcontent-vsf-c73="">
                                  <li _ngcontent-vsf-c73="">
                                    <!----><!----><a
                                      _ngcontent-vsf-c73=""
                                      data-toggle="collapse"
                                      role="button"
                                      aria-expanded="true"
                                      data-savepage-href="#SubMenu50"
                                      href="https://cricket247buzz.com/#SubMenu50"
                                      >Live Games
                                      <b _ngcontent-vsf-c73="" class="iconsmenu"
                                        ><i
                                          _ngcontent-vsf-c73=""
                                          class="fa fa-chevron-down"
                                        ></i></b></a
                                    ><!---->
                                    <div
                                      _ngcontent-vsf-c73=""
                                      class="collapse"
                                      id="SubMenu50"
                                    >
                                      <ul _ngcontent-vsf-c73="">
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67580"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67580"
                                            routerlinkactive="active-menu"
                                          >
                                            Casino War
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/90100"
                                            href="https://cricket247buzz.com/exchange-game/1444001/90100"
                                            routerlinkactive="active-menu"
                                          >
                                            Race 20-20
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67610"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67610"
                                            routerlinkactive="active-menu"
                                          >
                                            Trio
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67680"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67680"
                                            routerlinkactive="active-menu"
                                          >
                                            The Trap
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67570"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67570"
                                            routerlinkactive="active-menu"
                                          >
                                            Bollywood Casino
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67620"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67620"
                                            routerlinkactive="active-menu"
                                          >
                                            Queen
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67630"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67630"
                                            routerlinkactive="active-menu"
                                          >
                                            Teenpatti Test
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/92038"
                                            href="https://cricket247buzz.com/exchange-game/1444001/92038"
                                            routerlinkactive="active-menu"
                                          >
                                            Baccarat
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67567"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67567"
                                            routerlinkactive="active-menu"
                                          >
                                            Poker 2020
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67600"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67600"
                                            routerlinkactive="active-menu"
                                          >
                                            Mulfis Teenpatti
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67660"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67660"
                                            routerlinkactive="active-menu"
                                          >
                                            2 Cards Teenpatti
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67575"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67575"
                                            routerlinkactive="active-menu"
                                          >
                                            Casino Meter
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98566"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98566"
                                            routerlinkactive="active-menu"
                                          >
                                            Sicbo
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/56767"
                                            href="https://cricket247buzz.com/exchange-game/1444001/56767"
                                            routerlinkactive="active-menu"
                                          >
                                            1 Day Teenpatti
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67564"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67564"
                                            routerlinkactive="active-menu"
                                          >
                                            1 Day Poker
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98788"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98788"
                                            routerlinkactive="active-menu"
                                          >
                                            Roulette
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98790"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98790"
                                            routerlinkactive="active-menu"
                                          >
                                            1 Day Dragon Tiger
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98791"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98791"
                                            routerlinkactive="active-menu"
                                          >
                                            Amar Akbar Anthony
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/87564"
                                            href="https://cricket247buzz.com/exchange-game/1444001/87564"
                                            routerlinkactive="active-menu"
                                          >
                                            Andar Bahar
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98789"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98789"
                                            routerlinkactive="active-menu"
                                          >
                                            7 Up &amp; Down
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/92037"
                                            href="https://cricket247buzz.com/exchange-game/1444001/92037"
                                            routerlinkactive="active-menu"
                                          >
                                            Worli Matka
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/56768"
                                            href="https://cricket247buzz.com/exchange-game/1444001/56768"
                                            routerlinkactive="active-menu"
                                          >
                                            Teenpatti T20
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/56967"
                                            href="https://cricket247buzz.com/exchange-game/1444001/56967"
                                            routerlinkactive="active-menu"
                                          >
                                            32 Card Casino
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/56968"
                                            href="https://cricket247buzz.com/exchange-game/1444001/56968"
                                            routerlinkactive="active-menu"
                                          >
                                            Hi-Low
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/56766"
                                            href="https://cricket247buzz.com/exchange-game/1444001/56766"
                                            routerlinkactive="active-menu"
                                          >
                                            Teenpatti One-Day (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/56769"
                                            href="https://cricket247buzz.com/exchange-game/1444001/56769"
                                            routerlinkactive="active-menu"
                                          >
                                            Teenpatti T20 (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98793"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98793"
                                            routerlinkactive="active-menu"
                                          >
                                            7 up &amp; down (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/56966"
                                            href="https://cricket247buzz.com/exchange-game/1444001/56966"
                                            routerlinkactive="active-menu"
                                          >
                                            32 Cards (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67563"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67563"
                                            routerlinkactive="active-menu"
                                          >
                                            Poker (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/67566"
                                            href="https://cricket247buzz.com/exchange-game/1444001/67566"
                                            routerlinkactive="active-menu"
                                          >
                                            Six player poker (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/87565"
                                            href="https://cricket247buzz.com/exchange-game/1444001/87565"
                                            routerlinkactive="active-menu"
                                          >
                                            Andar Bahar (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/92036"
                                            href="https://cricket247buzz.com/exchange-game/1444001/92036"
                                            routerlinkactive="active-menu"
                                          >
                                            Matka (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98792"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98792"
                                            routerlinkactive="active-menu"
                                          >
                                            Roulette (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98794"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98794"
                                            routerlinkactive="active-menu"
                                          >
                                            Dragon Tiger (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <ul _ngcontent-vsf-c73="">
                                        <li _ngcontent-vsf-c73="">
                                          <a
                                            _ngcontent-vsf-c73=""
                                            data-savepage-href="/exchange-game/1444001/98795"
                                            href="https://cricket247buzz.com/exchange-game/1444001/98795"
                                            routerlinkactive="active-menu"
                                          >
                                            Amar Akbar Anthony (Virtual)
                                          </a>
                                        </li>
                                        <!----><!---->
                                      </ul>
                                      <!---->
                                    </div>
                                  </li>
                                  <!---->
                                </ul>
                              </div>
                            </div>
                            <!---->
                          </li>
                          <li _ngcontent-vsf-c73=""><!----></li>
                          <!---->
                        </ul>
                      </div>
                    </li>
                    <!---->
                  </ul>
                </nav>
                <!----></app-sidebar
              >