<div _ngcontent-uhn-c72="" class="header-bottom">
          <div _ngcontent-uhn-c72="" class="row mx-lg-0">
            <div _ngcontent-uhn-c72="" class="col-md-12">
              <nav _ngcontent-uhn-c72="" class="navbar navbar-expand-md btco-hover-menu"><button _ngcontent-uhn-c72=""
                  type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
                  aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"
                  class="navbar-toggler"><span _ngcontent-uhn-c72="" class="navbar-toggler-icon"></span></button>
                <div _ngcontent-uhn-c72="" class="collapse navbar-collapse">
                  <ul _ngcontent-uhn-c72="" class="list-unstyled navbar-nav">
                    <li class="nav-item active"><a routerlink="/sports/4" href="{{route('client-home')}}" class="router-link-exact-active router-link-active"><b>Home</b></a></li>
                            <li class="nav-item"><a href="{{route('client-home')}}" class="router-link-exact-active router-link-active"><b>Cricket</b></a>
                            </li>
                            <li class="nav-item"><a href="{{route('football-frontend')}}"><b>Football</b></a></li>
                            <li class="nav-item"><a href="{{route('tennis-frontend')}}"><b>Tennis</b></a></li>
                            <li class="nav-item"><a href="javascript:void(0)"><b>Election</b></a></li>
                            <li class="nav-item"><a href="{{route('client-home')}}"><b>IPL
                                        2024</b></a></li>
                            <li class="nav-item"><a href="https://crickekbuz.art/slot/game/lounch/9280"><b>One-Day
                                        Teenpatti</b></a></li>
                            <li class="nav-item"><a href="https://crickekbuz.art/slot/game/lounch/9646"><b>Roulette</b></a></li>
                            <li class="nav-item"><a href="{{route('horse')}}"><b>Horse Racing</b></a></li>
                            <li class="nav-item"><a href="{{route('greyhound')}}"><b>Greyhound Racing</b></a></li>
                            <li class="nav-item"><a href="https://crickekbuz.art/slot/game/lounch/9686"><b>Sicbo</b></a></li>
                            <li class="nav-item"><a href="https://crickekbuz.art/slot/game/lounch/9690"><b>Poker</b></a></li>
                            <li class="nav-item"><a href="https://crickekbuz.art/slot/game/lounch/12959"><b>Andar
                                        Bahar</b></a></li>
                            <li class="nav-item"><a href="https://crickekbuz.art/slot/game/lounch/9678"><b>One-Day
                                        Dragon Tiger</b></a></li><!---->
                  </ul><!---->
                </div>
              </nav>
            </div>
          </div>
        </div><!---->