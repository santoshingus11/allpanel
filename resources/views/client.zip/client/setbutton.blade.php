@extends('web_layout.app')
@section('style')

@endsection
@section('content')
<div class="col-md-10 pxxs-0"><router-outlet></router-outlet><app-change-btn-value _nghost-phe-c76="">
        <div class="wrapper-inner user_screen button-value">
            <h2 class="user-title">Change Betslip Buttons Value</h2>
            <div class="border border-light p-2">
                <div class="form-group row mb-0">
                    <div class="col-md-3 col-6"><span><b>Price Value</b></span></div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 col-6"><input type="number" id="" placeholder="1000" class="form-control ng-untouched ng-pristine ng-valid"></div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 col-6"><input type="number" id="" placeholder="1000" class="form-control ng-untouched ng-pristine ng-valid"></div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 col-6"><input type="number" id="" placeholder="1000" class="form-control ng-untouched ng-pristine ng-valid"></div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 col-6"><input type="number" id="" placeholder="1000" class="form-control ng-untouched ng-pristine ng-valid"></div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 col-6"><input type="number" id="" placeholder="1000" class="form-control ng-untouched ng-pristine ng-valid"></div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 col-6"><input type="number" id="" placeholder="1000" class="form-control ng-untouched ng-pristine ng-valid"></div>
                </div><!---->
                <div class="form-group row">
                    <div class="col-md-3 col-12"><button class="btn btn-primary">Update</button></div>
                </div>
            </div>
        </div>
    </app-change-btn-value><!----></div>

@endsection
@section('script')
<script>
    /* Script Goes Here */

    /* Script Goes Here */
</script>
@endsection