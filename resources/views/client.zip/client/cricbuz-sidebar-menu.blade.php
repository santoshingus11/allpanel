<nav _ngcontent-uhn-c73="" class="nav-menu">
                <ul _ngcontent-uhn-c73="">
                  <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73="" data-toggle="collapse"
                      href="https://crickekbuz.art/assets/#SubsideMenu1" role="button" aria-expanded="true"
                      aria-controls="SubsideMenu1" class="active"><span _ngcontent-uhn-c73="">Casino</span><b
                        _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                          class="fa fa-chevron-down"></i></b></a>
                    <div _ngcontent-uhn-c73="" id="SubsideMenu1" class="collapse show">
                      <ul _ngcontent-uhn-c73=""><!----><!----></ul>
                      <ul _ngcontent-uhn-c73=""><!----><!----></ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Casino War
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Race 20-20
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Trio </span></a>
                        </li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> The Trap
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Bollywood Casino
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Queen
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Teenpatti Test
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Baccarat
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Poker 2020
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Mulfis Teenpatti
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 2 Cards
                              Teenpatti </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Casino Meter
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Sicbo
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 1 Day Teenpatti
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 1 Day Poker
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Roulette
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 1 Day Dragon
                              Tiger </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Amar Akbar
                              Anthony </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Andar Bahar
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 7 Up &amp; Down
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Worli Matka
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Teenpatti T20
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 32 Card Casino
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Hi-Low
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Teenpatti
                              One-Day (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Teenpatti T20
                              (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 7 up &amp; down
                              (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> 32 Cards
                              (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Poker (Virtual)
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Six player poker
                              (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Andar Bahar
                              (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Matka (Virtual)
                            </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Roulette
                              (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Dragon Tiger
                              (Virtual) </span></a></li><!---->
                      </ul>
                      <ul _ngcontent-uhn-c73=""><!---->
                        <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""><span _ngcontent-uhn-c73=""> Amar Akbar
                              Anthony (Virtual) </span></a></li><!---->
                      </ul><!---->
                    </div>
                  </li><!---->
                  <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73="" data-toggle="collapse"
                      href="https://crickekbuz.art/assets/#SubsideMenu2" role="button" aria-expanded="true"
                      aria-controls="SubsideMenu1" class="active"><span _ngcontent-uhn-c73="">Sports</span><b
                        _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                          class="fa fa-chevron-down"></i></b></a>
                    <div _ngcontent-uhn-c73="" id="SubsideMenu2" class="collapse show">
                      <ul _ngcontent-uhn-c73="">
                        <li _ngcontent-uhn-c73="">
                          <div _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73="" data-toggle="collapse" role="button"
                              aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu0">Cricket <b
                                _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                  class="fa fa-chevron-down"></i></b></a>
                            <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu0">
                              <ul _ngcontent-uhn-c73="">
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu00">Indian Premier League <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu00">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/28127348"
                                          routerlinkactive="active-menu"> Indian Premier League </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33244358"
                                          routerlinkactive="active-menu" class="active-menu"> Sunrisers Hyderabad v
                                          Lucknow Super Giants </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33246936"
                                          routerlinkactive="active-menu"> Kolkata Knight Riders v Mumbai Indians </a>
                                      </li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33252847"
                                          routerlinkactive="active-menu"> Chennai Super Kings v Rajasthan Royals </a>
                                      </li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33244280"
                                          routerlinkactive="active-menu"> Punjab Kings v Royal Challengers Bengaluru
                                        </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33244304"
                                          routerlinkactive="active-menu"> Gujarat Titans v Chennai Super Kings </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33252848"
                                          routerlinkactive="active-menu"> Royal Challengers Bengaluru v Delhi Capitals
                                        </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33252860"
                                          routerlinkactive="active-menu"> Gujarat Titans v Kolkata Knight Riders </a>
                                      </li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33252133"
                                          routerlinkactive="active-menu"> Delhi Capitals v Lucknow Super Giants </a>
                                      </li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu01">Election <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu01">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/240113031023"
                                          routerlinkactive="active-menu"> BJP LS v CON LS </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu02">Cool
                                    and Smooth T10 <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu02">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49836657"
                                          routerlinkactive="active-menu"> Government Road Stingrays vs. Brownhill
                                          Dolphins </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49836719"
                                          routerlinkactive="active-menu"> Haynes Smith Sharks vs. Sandy Point Snappers
                                        </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu03">International Twenty20 Matches <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu03">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33254570"
                                          routerlinkactive="active-menu"> Bangladesh v Zimbabwe </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33254631"
                                          routerlinkactive="active-menu"> Ireland v Pakistan </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu04">ECS
                                    Italy, Brescia <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu04">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49599113"
                                          routerlinkactive="active-menu"> Trentino Aquila vs. Friends Xi </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu05">Pakistan Super League SRL <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu05">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708553"
                                          routerlinkactive="active-menu"> Multan Sultans Srl vs. Quetta Gladiators Srl
                                        </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708555"
                                          routerlinkactive="active-menu"> Karachi Kings Srl vs. Islamabad United Srl
                                        </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708557"
                                          routerlinkactive="active-menu"> Multan Sultans Srl vs. Lahore Qalanders Srl
                                        </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708559"
                                          routerlinkactive="active-menu"> Quetta Gladiators Srl vs. Peshawar Zalmi SRL
                                        </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu06">SA
                                    T20 League SRL <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu06">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708679"
                                          routerlinkactive="active-menu"> Joburg Super Kings Srl vs. Durban Super Giants
                                          Srl </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708681"
                                          routerlinkactive="active-menu"> Paarl Royals Srl vs. Mi Cape Town Srl </a>
                                      </li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708683"
                                          routerlinkactive="active-menu"> Sunrisers Eastern Cape Srl vs. Pretoria
                                          Capitals Srl </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu07">Inter Provincial Trophy <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu07">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49534385"
                                          routerlinkactive="active-menu"> Northern Knights vs. North-West Warriors </a>
                                      </li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu08">Guyana T10 Blast <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu08">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49594653"
                                          routerlinkactive="active-menu"> Essequibo Anacondas vs. Berbice Caimans </a>
                                      </li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49941003"
                                          routerlinkactive="active-menu"> Essequibo Jaguars vs. Demerara Pitbulls </a>
                                      </li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu09">T20
                                    International SRL <b _ngcontent-uhn-c73="" class="iconsmenu"><i
                                        _ngcontent-uhn-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu09">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708979"
                                          routerlinkactive="active-menu"> Pakistan SRL vs. India SRL </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708981"
                                          routerlinkactive="active-menu"> England SRL vs. Australia SRL </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708983"
                                          routerlinkactive="active-menu"> Afghanistan Srl vs. West Indies Srl </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708985"
                                          routerlinkactive="active-menu"> South Africa SRL vs. India SRL </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708987"
                                          routerlinkactive="active-menu"> Sri Lanka Srl vs. New Zealand SRL </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu010">Caribbean Premier League SRL <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu010">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708385"
                                          routerlinkactive="active-menu"> St Kitts And Nevis Patriots Srl vs. Guyana
                                          Amazon Warriors Srl </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708387"
                                          routerlinkactive="active-menu"> Barbados Royals Srl vs. Jamaica Tallawahs SRL
                                        </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708389"
                                          routerlinkactive="active-menu"> St Lucia Kings Srl vs. St Kitts And Nevis
                                          Patriots Srl </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708391"
                                          routerlinkactive="active-menu"> Guyana Amazon Warriors Srl vs. Trinbago Knight
                                          Riders SRL </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu011">Big
                                    Bash League SRL <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu011">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708247"
                                          routerlinkactive="active-menu"> Adelaide Strikers Srl vs. Hobart Hurricanes
                                          Srl </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/49708249"
                                          routerlinkactive="active-menu"> Brisbane Heat Srl vs. Melbourne Renegades Srl
                                        </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu012">Womens International Twenty20 Matches
                                    <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu012">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/4/33251361"
                                          routerlinkactive="active-menu"> Bangladesh Women v India Women </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li><!---->
                              </ul>
                            </div>
                          </div><!---->
                        </li>
                        <li _ngcontent-uhn-c73="">
                          <div _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73="" data-toggle="collapse" role="button"
                              aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu1">Football <b
                                _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                  class="fa fa-chevron-down"></i></b></a>
                            <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu1">
                              <ul _ngcontent-uhn-c73="">
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu10">U19
                                    Serbian League <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu10">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49654317"
                                          routerlinkactive="active-menu"> Partizan Belgrad vs. FK Jedinstvo Ub </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49654321"
                                          routerlinkactive="active-menu"> FK IMT vs. FK Spartak Zdrepceva Krv </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49654325"
                                          routerlinkactive="active-menu"> FK Zemun vs. FK Vozdovac </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu11">Victoria NPL, Women <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu11">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/48858313"
                                          routerlinkactive="active-menu"> Preston Lions vs. South Melbourne FC </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu12">Zone
                                    Moscow <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu12">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49654029"
                                          routerlinkactive="active-menu"> Torpedo-M Moscow vs. Krasnaia Zvezda </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49654035"
                                          routerlinkactive="active-menu"> FSM Moscow vs. Zelenograd </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu13">FA
                                    Cup <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu13">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49385919"
                                          routerlinkactive="active-menu"> DP Kanchanaburi FC vs. Samut Sakhon City FC
                                        </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu14">Higher League <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu14">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49914909"
                                          routerlinkactive="active-menu"> Jimma Aba Jifar FC vs. Halaba Ketema </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu15">V-League 1 <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu15">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49167135"
                                          routerlinkactive="active-menu"> K. Khanh Hoa vs. Haiphong FC </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu16">Cambodian Premier League <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu16">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49594767"
                                          routerlinkactive="active-menu"> Preah Khan Reach Svay Rieng FC vs. Visakha FC
                                        </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49594765"
                                          routerlinkactive="active-menu"> Boeung Ket Angkor FC vs. Phnom Penh Crown FC
                                        </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu17">Super League <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu17">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49924515"
                                          routerlinkactive="active-menu"> Kisumu All Stars FC vs. SS Assad </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu18">Krajsky prebor <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu18">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49903067"
                                          routerlinkactive="active-menu"> Zruc vs. Tj Plzen Kosutka </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu19">Cupa
                                    Romaniei, Women <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu19">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49659873"
                                          routerlinkactive="active-menu"> Olimpia Cluj vs. Afk Csikszereda Miercurea
                                          Ciuc </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu110">Liga 3 <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu110">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/48945257"
                                          routerlinkactive="active-menu"> AFC Metalul Buzau vs. ASC Unirea Branistea
                                        </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu111">UEFA Champions League SRL <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu111">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/49949659"
                                          routerlinkactive="active-menu"> Real Madrid SRL vs. Bayern Munich SRL </a>
                                      </li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu112">UEFA Europa Conference League <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu112">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242963"
                                          routerlinkactive="active-menu"> Club Brugge v Fiorentina </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu113">UEFA Champions League <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu113">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33237980"
                                          routerlinkactive="active-menu"> Real Madrid v Bayern Munich </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu114">UEFA Europa League <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu114">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242897"
                                          routerlinkactive="active-menu"> Atalanta v Marseille </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu115">German Bundesliga <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu115">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232196"
                                          routerlinkactive="active-menu"> Augsburg v Stuttgart </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232209"
                                          routerlinkactive="active-menu"> Freiburg v FC Heidenheim </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232244"
                                          routerlinkactive="active-menu"> RB Leipzig v Werder Bremen </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232224"
                                          routerlinkactive="active-menu"> FC Koln v Union Berlin </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232239"
                                          routerlinkactive="active-menu"> Mgladbach v Eintracht Frankfurt </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232199"
                                          routerlinkactive="active-menu"> Mainz v Dortmund </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232265"
                                          routerlinkactive="active-menu"> SV Darmstadt v Hoffenheim </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232269"
                                          routerlinkactive="active-menu"> Bayern Munich v Wolfsburg </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242791"
                                          routerlinkactive="active-menu"> Bochum v Leverkusen </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu116">Italian Serie A <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu116">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33243059"
                                          routerlinkactive="active-menu"> Frosinone v Inter </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232206"
                                          routerlinkactive="active-menu"> Fiorentina v AC Monza </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242806"
                                          routerlinkactive="active-menu"> Lecce v Udinese </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242813"
                                          routerlinkactive="active-menu"> Napoli v Bologna </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242387"
                                          routerlinkactive="active-menu"> AC Milan v Cagliari </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232263"
                                          routerlinkactive="active-menu"> Lazio v Empoli </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242667"
                                          routerlinkactive="active-menu"> Verona v Torino </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242683"
                                          routerlinkactive="active-menu"> Genoa v Sassuolo </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242549"
                                          routerlinkactive="active-menu"> Juventus v Salernitana </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232261"
                                          routerlinkactive="active-menu"> Atalanta v Roma </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu117">French Ligue 1 <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu117">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232192"
                                          routerlinkactive="active-menu"> Nice v Le Havre </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232638"
                                          routerlinkactive="active-menu"> Brest v Reims </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232334"
                                          routerlinkactive="active-menu"> Marseille v Lorient </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232355"
                                          routerlinkactive="active-menu"> Paris St-G v Toulouse </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232354"
                                          routerlinkactive="active-menu"> Nantes v Lille </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242805"
                                          routerlinkactive="active-menu"> Montpellier v Monaco </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232341"
                                          routerlinkactive="active-menu"> Clermont v Lyon </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232236"
                                          routerlinkactive="active-menu"> Strasbourg v Metz </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232270"
                                          routerlinkactive="active-menu"> Rennes v Lens </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33250509"
                                          routerlinkactive="active-menu"> Nice v Paris St-G </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu118">Spanish La Liga <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu118">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232277"
                                          routerlinkactive="active-menu"> Alaves v Girona </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232345"
                                          routerlinkactive="active-menu"> Mallorca v Las Palmas </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232340"
                                          routerlinkactive="active-menu"> Villarreal v Sevilla </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232267"
                                          routerlinkactive="active-menu"> Granada v Real Madrid </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232287"
                                          routerlinkactive="active-menu"> Athletic Bilbao v Osasuna </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232285"
                                          routerlinkactive="active-menu"> Cadiz v Getafe </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232282"
                                          routerlinkactive="active-menu"> Atletico Madrid v Celta Vigo </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232281"
                                          routerlinkactive="active-menu"> Valencia v Rayo Vallecano </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232286"
                                          routerlinkactive="active-menu"> Betis v Almeria </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232289"
                                          routerlinkactive="active-menu"> Barcelona v Real Sociedad </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu119">English League 2 <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu119">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33253089"
                                          routerlinkactive="active-menu"> Doncaster v Crewe </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu120">English Premier League <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu120">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232234"
                                          routerlinkactive="active-menu"> Fulham v Man City </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232260"
                                          routerlinkactive="active-menu"> Bournemouth v Brentford </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232254"
                                          routerlinkactive="active-menu"> West Ham v Luton </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232255"
                                          routerlinkactive="active-menu"> Everton v Sheff Utd </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232259"
                                          routerlinkactive="active-menu"> Tottenham v Burnley </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232222"
                                          routerlinkactive="active-menu"> Newcastle v Brighton </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232223"
                                          routerlinkactive="active-menu"> Wolves v Crystal Palace </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232221"
                                          routerlinkactive="active-menu"> Nottm Forest v Chelsea </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33242097"
                                          routerlinkactive="active-menu"> Man Utd v Arsenal </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33232351"
                                          routerlinkactive="active-menu"> Aston Villa v Liverpool </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu121">US
                                    Major League Football <b _ngcontent-uhn-c73="" class="iconsmenu"><i
                                        _ngcontent-uhn-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu121">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33233097"
                                          routerlinkactive="active-menu"> Philadelphia v Orlando City </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33249270"
                                          routerlinkactive="active-menu"> Philadelphia v New York City </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu122">German Cup <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu122">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33164647"
                                          routerlinkactive="active-menu"> Kaiserslautern v Leverkusen </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu123">French Cup <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu123">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33165611"
                                          routerlinkactive="active-menu"> Lyon v Paris St-G </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu124">UEFA Euro 2024 <b
                                      _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu124">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949254"
                                          routerlinkactive="active-menu"> Germany v Scotland </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949256"
                                          routerlinkactive="active-menu"> Hungary v Switzerland </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949282"
                                          routerlinkactive="active-menu"> Spain v Croatia </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949284"
                                          routerlinkactive="active-menu"> Italy v Albania </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/33143036"
                                          routerlinkactive="active-menu"> Poland v Netherlands </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949285"
                                          routerlinkactive="active-menu"> Slovenia v Denmark </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949287"
                                          routerlinkactive="active-menu"> Serbia v England </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949292"
                                          routerlinkactive="active-menu"> Belgium v Slovakia </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949297"
                                          routerlinkactive="active-menu"> Austria v France </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/32949298"
                                          routerlinkactive="active-menu"> Portugal v Czech Republic </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true"
                                    href="https://crickekbuz.art/assets/#SubMenu125">Copa America <b _ngcontent-uhn-c73=""
                                      class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu125">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023231"
                                          routerlinkactive="active-menu"> Argentina vs. Canada </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023233"
                                          routerlinkactive="active-menu"> Peru vs. Chile </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023489"
                                          routerlinkactive="active-menu"> Mexico vs. Jamaica </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023491"
                                          routerlinkactive="active-menu"> Ecuador vs. Venezuela </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023625"
                                          routerlinkactive="active-menu"> Uruguay vs. Panama </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023623"
                                          routerlinkactive="active-menu"> USA vs. Bolivia </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023761"
                                          routerlinkactive="active-menu"> Colombia vs. Paraguay </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/1/46023759"
                                          routerlinkactive="active-menu"> Brazil vs. Costa Rica </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li><!---->
                              </ul>
                            </div>
                          </div><!---->
                        </li>
                        <li _ngcontent-uhn-c73="">
                          <div _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73="" data-toggle="collapse" role="button"
                              aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu2">Tennis <b
                                _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                  class="fa fa-chevron-down"></i></b></a>
                            <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu2">
                              <ul _ngcontent-uhn-c73="">
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu20">ATP
                                    Rome <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu20">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255143"
                                          routerlinkactive="active-menu"> Luciano Darderi v Denis Shapovalov </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255146"
                                          routerlinkactive="active-menu"> Nuno Borges v Pedro Martinez </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255145"
                                          routerlinkactive="active-menu"> Pavel Kotov v Alex Michelsen </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255979"
                                          routerlinkactive="active-menu"> Maximilian Marterer v Flavio Cobolli </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255015"
                                          routerlinkactive="active-menu"> Alexander Shevchenko v Fabian Marozsan </a>
                                      </li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255975"
                                          routerlinkactive="active-menu"> Thiago Monteiro v Gael Monfils </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255983"
                                          routerlinkactive="active-menu"> Diego Schwartzman v Aleksandar Vukic </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu21">ATP
                                    Francavilla Challenger <b _ngcontent-uhn-c73="" class="iconsmenu"><i
                                        _ngcontent-uhn-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu21">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33253153"
                                          routerlinkactive="active-menu"> Marco Cecchinato v Franco Agamenone </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255036"
                                          routerlinkactive="active-menu"> Maks Kasnikowski v Nick Hardt </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33253152"
                                          routerlinkactive="active-menu"> Adrian Andreev v Andrea Pellegrino </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255508"
                                          routerlinkactive="active-menu"> Ryan Nijboer v Federico Arnaboldi </a></li>
                                      <!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu22">WTA
                                    Rome 2024 <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu22">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33252009"
                                          routerlinkactive="active-menu"> D Parry v Blinkova </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255770"
                                          routerlinkactive="active-menu"> Karolina Schmiedlova v A Sasnovich </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255765"
                                          routerlinkactive="active-menu"> Taylo Townsend v Bre Fruhvirtova </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255775"
                                          routerlinkactive="active-menu"> Dolehide v Pera </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33251975"
                                          routerlinkactive="active-menu"> N Osaka v Burel </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33252014"
                                          routerlinkactive="active-menu"> L Zhu v Mag Linette </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33252019"
                                          routerlinkactive="active-menu"> P Martic v M Sherif </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255786"
                                          routerlinkactive="active-menu"> Reb Masarova v I Begu </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33252004"
                                          routerlinkactive="active-menu"> K Siniakova v Nur Brancaccio </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33251999"
                                          routerlinkactive="active-menu"> Sof Kenin v L Bronzetti </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33252038"
                                          routerlinkactive="active-menu"> A Potapova v X Wang </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255781"
                                          routerlinkactive="active-menu"> Zarazua v El Cocciaretto </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33252028"
                                          routerlinkactive="active-menu"> Podoroska v Sorribes Tormo </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255813"
                                          routerlinkactive="active-menu"> Yaf Wang v Volynets </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255760"
                                          routerlinkactive="active-menu"> Di Sarra v V Gracheva </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255791"
                                          routerlinkactive="active-menu"> Sramkova v Pedone </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255803"
                                          routerlinkactive="active-menu"> D Saville v C Tauson </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li>
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu23">ATP
                                    Mauthausen Challenger <b _ngcontent-uhn-c73="" class="iconsmenu"><i
                                        _ngcontent-uhn-c73="" class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu23">
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33254583"
                                          routerlinkactive="active-menu"> Filip Misolic v Ugo Blanchet </a></li><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255044"
                                          routerlinkactive="active-menu"> Otto Virtanen v Max Hans Rehberg </a></li>
                                      <!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!---->
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/sport-event/detail/2/33255043"
                                          routerlinkactive="active-menu"> Lucas Pouille v Jan Choinski </a></li><!---->
                                    </ul><!---->
                                  </div>
                                </li><!---->
                              </ul>
                            </div>
                          </div><!---->
                        </li>
                        <li _ngcontent-uhn-c73=""><!----></li>
                        <li _ngcontent-uhn-c73=""><!----></li>
                        <li _ngcontent-uhn-c73="">
                          <div _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73="" data-toggle="collapse" role="button"
                              aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu5">Exchange Game <b
                                _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                  class="fa fa-chevron-down"></i></b></a>
                            <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu5">
                              <ul _ngcontent-uhn-c73="">
                                <li _ngcontent-uhn-c73=""><!----><!----><a _ngcontent-uhn-c73="" data-toggle="collapse"
                                    role="button" aria-expanded="true" href="https://crickekbuz.art/assets/#SubMenu50">Live
                                    Games <b _ngcontent-uhn-c73="" class="iconsmenu"><i _ngcontent-uhn-c73=""
                                        class="fa fa-chevron-down"></i></b></a><!---->
                                  <div _ngcontent-uhn-c73="" class="collapse" id="SubMenu50">
                                    <ul _ngcontent-uhn-c73=""><!----><!----></ul>
                                    <ul _ngcontent-uhn-c73=""><!----><!----></ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67580"
                                          routerlinkactive="active-menu"> Casino War </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/90100"
                                          routerlinkactive="active-menu"> Race 20-20 </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67610"
                                          routerlinkactive="active-menu"> Trio </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67680"
                                          routerlinkactive="active-menu"> The Trap </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67570"
                                          routerlinkactive="active-menu"> Bollywood Casino </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67620"
                                          routerlinkactive="active-menu"> Queen </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67630"
                                          routerlinkactive="active-menu"> Teenpatti Test </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/92038"
                                          routerlinkactive="active-menu"> Baccarat </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67567"
                                          routerlinkactive="active-menu"> Poker 2020 </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67600"
                                          routerlinkactive="active-menu"> Mulfis Teenpatti </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67660"
                                          routerlinkactive="active-menu"> 2 Cards Teenpatti </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67575"
                                          routerlinkactive="active-menu"> Casino Meter </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98566"
                                          routerlinkactive="active-menu"> Sicbo </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/56767"
                                          routerlinkactive="active-menu"> 1 Day Teenpatti </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67564"
                                          routerlinkactive="active-menu"> 1 Day Poker </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98788"
                                          routerlinkactive="active-menu"> Roulette </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98790"
                                          routerlinkactive="active-menu"> 1 Day Dragon Tiger </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98791"
                                          routerlinkactive="active-menu"> Amar Akbar Anthony </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/87564"
                                          routerlinkactive="active-menu"> Andar Bahar </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98789"
                                          routerlinkactive="active-menu"> 7 Up &amp; Down </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/92037"
                                          routerlinkactive="active-menu"> Worli Matka </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!----><!----></ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/56768"
                                          routerlinkactive="active-menu"> Teenpatti T20 </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/56967"
                                          routerlinkactive="active-menu"> 32 Card Casino </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/56968"
                                          routerlinkactive="active-menu"> Hi-Low </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/56766"
                                          routerlinkactive="active-menu"> Teenpatti One-Day (Virtual) </a></li>
                                      <!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/56769"
                                          routerlinkactive="active-menu"> Teenpatti T20 (Virtual) </a></li>
                                      <!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98793"
                                          routerlinkactive="active-menu"> 7 up &amp; down (Virtual) </a></li>
                                      <!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/56966"
                                          routerlinkactive="active-menu"> 32 Cards (Virtual) </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73=""><!----><!----></ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67563"
                                          routerlinkactive="active-menu"> Poker (Virtual) </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/67566"
                                          routerlinkactive="active-menu"> Six player poker (Virtual) </a></li>
                                      <!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/87565"
                                          routerlinkactive="active-menu"> Andar Bahar (Virtual) </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/92036"
                                          routerlinkactive="active-menu"> Matka (Virtual) </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98792"
                                          routerlinkactive="active-menu"> Roulette (Virtual) </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98794"
                                          routerlinkactive="active-menu"> Dragon Tiger (Virtual) </a></li><!----><!---->
                                    </ul>
                                    <ul _ngcontent-uhn-c73="">
                                      <li _ngcontent-uhn-c73=""><a _ngcontent-uhn-c73=""
                                          href="https://crickekbuz.art/assets/exchange-game/1444001/98795"
                                          routerlinkactive="active-menu"> Amar Akbar Anthony (Virtual) </a></li>
                                      <!----><!---->
                                    </ul><!---->
                                  </div>
                                </li><!---->
                              </ul>
                            </div>
                          </div><!---->
                        </li>
                        <li _ngcontent-uhn-c73=""><!----></li><!---->
                      </ul>
                    </div>
                  </li><!---->
                </ul>
              </nav><!---->